# Fondeo: inspect the working example

This source package contains the actual rules and service behind the guided invoice investigation. The sample source total is $1,300; the authored extraction is $1,800 at 97% confidence. No OCR/model call produced these sample values.

With Node.js 22.13 or newer, unzip the package and run from its directory:

```sh
node --test scripts/investigation-service.test.mjs scripts/document-workbench.test.mjs
```

No package installation, account, cloud credential, or network service is needed. The tests start short-lived loopback HTTP servers and use SQLite on this computer. Test-owned temporary files are removed after completion.

## What to inspect

- `lib/document-rules.mjs`: source, arithmetic, confidence and revision rules. These pure functions are shared with the browser example.
- `scripts/document-workbench.mjs`: transactional creation and compare-and-swap updates. Its original durable workspace is separate from the guided service.
- `scripts/investigation-service.mjs`: one isolated synthetic case per visitor, bounded temporary sessions, source-host/origin checks, and request receipts. This service explicitly uses an in-memory SQLite database, not the original workspace file.
- `scripts/investigation-service.test.mjs`: actual HTTP correction/approval/stale-write flow; visitor isolation; invalid inputs; concurrency; reset/expiry and request limits.
- `scripts/document-workbench.test.mjs`: original workspace's tenant, idempotency, revision, approval and persistence checks.

A successful guided run changes revision 1 to a corrected revision 2, then records approval of that revision in revision 3. An attempted write carrying revision 1 receives HTTP 409. The request receipt records that response and the current case remains unchanged. Approving a document is a synthetic demonstration, not a payment or financial authorization.

## Scope of the evidence

The browser example applies the same pure rules on the visitor's device. The live example sends requests to the Node/SQLite service. Its execution mode, request IDs, revision and response status are reported by that service. Reproducing these tests verifies the bounded example; it does not certify a production multi-tenant product or prove anything about an employer's private systems.

The Python/AWS extension is a separate source package. It must not be confused with the Node service running this example. Real cloud execution and current OCR/model output require their own evidence.
