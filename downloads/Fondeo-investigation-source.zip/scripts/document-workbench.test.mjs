import assert from 'node:assert/strict';
import test from 'node:test';
import { createServer, request as httpRequest } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createDocumentHandler } from './document-workbench.mjs';

async function start(filename) {
  const server = createServer(async (req, res) => {
    const pathname = new URL(req.url, 'http://localhost').pathname;
    if (!(await handler(req, res, pathname))) {
      res.writeHead(404);
      res.end('Outside document handler');
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const handler = createDocumentHandler({ port, filename });
  let closed = false;
  return {
    port,
    async close() {
      if (closed) return;
      closed = true;
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
      handler.close();
    },
    async request(
      route = '',
      {
        method = 'GET',
        body,
        raw,
        cookie,
        headers = {},
        omitLabHeader = false,
      } = {},
    ) {
      const response = await fetch(
        `http://127.0.0.1:${port}/api/documents${route}`,
        {
          method,
          headers: {
            ...(omitLabHeader ? {} : { 'X-Lab-Request': '1' }),
            ...(body !== undefined || raw !== undefined
              ? { 'Content-Type': 'application/json' }
              : {}),
            ...(cookie ? { Cookie: cookie } : {}),
            ...headers,
          },
          ...(method === 'GET'
            ? {}
            : {
                body:
                  raw !== undefined
                    ? raw
                    : body !== undefined
                      ? JSON.stringify(body)
                      : undefined,
              }),
          signal: AbortSignal.timeout(5000),
        },
      );
      const text = await response.text();
      return {
        status: response.status,
        headers: response.headers,
        body: response.headers.get('content-type')?.includes('json')
          ? JSON.parse(text)
          : text,
      };
    },
  };
}
async function fixture(t) {
  const directory = await mkdtemp(join(tmpdir(), 'document-workbench-test-'));
  const filename = join(directory, 'documents.sqlite');
  const app = await start(filename);
  const servers = [app];
  t.after(async () => {
    await Promise.all(servers.map((server) => server.close()));
    await rm(directory, { recursive: true, force: true });
  });
  return {
    app,
    filename,
    directory,
    restart: async () => {
      const next = await start(filename);
      servers.push(next);
      return next;
    },
  };
}
async function session(app, actor = 'isla') {
  const result = await app.request('/session', {
    method: 'POST',
    body: { actor },
  });
  assert.equal(result.status, 200);
  return { cookie: result.headers.get('set-cookie').split(';')[0], result };
}
void test('an intended workspace mismatch rejects cross-tab reads and creates', async (t) => {
  const { app } = await fixture(t);
  const { cookie } = await session(app, 'norte');
  const headers = { 'X-Lab-Workspace': 'isla-studio' };
  assert.equal((await app.request('', { cookie, headers })).status, 409);
  assert.equal(
    (
      await app.request('', {
        method: 'POST',
        cookie,
        headers,
        body: { fixture: 'clean', requestKey: 'cross-tab' },
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await app.request('', {
        cookie,
        headers: { 'X-Lab-Workspace': 'norte-studio' },
      })
    ).body.cases.length,
    0,
  );
});
async function create(
  app,
  cookie,
  fixtureName = 'clean',
  requestKey = 'case-one',
) {
  const result = await app.request('', {
    method: 'POST',
    cookie,
    body: { fixture: fixtureName, requestKey },
  });
  assert.equal(result.status, 200);
  return result.body.case;
}
async function patch(app, cookie, record, values = {}) {
  return app.request(`/${record.id}`, {
    method: 'PATCH',
    cookie,
    body: {
      revision: record.revision,
      amountCents: record.amountCents,
      verified: record.verified,
      ...values,
    },
  });
}
async function approve(app, cookie, record) {
  return app.request(`/${record.id}/approve`, {
    method: 'POST',
    cookie,
    body: { revision: record.revision },
  });
}

void test('HTTP boundary rejects missing header, foreign Origin, foreign Host and unauthenticated requests', async (t) => {
  const { app } = await fixture(t);
  assert.equal((await app.request()).status, 401);
  assert.equal(
    (
      await app.request('', {
        cookie: `lab-document-session=${'a'.repeat(64)}`,
      })
    ).status,
    401,
  );
  assert.equal((await app.request('', { omitLabHeader: true })).status, 403);
  for (const origin of [
    'https://example.com',
    'null',
    `http://127.0.0.1:${app.port}.evil.test`,
  ])
    assert.equal(
      (
        await app.request('/session', {
          method: 'POST',
          body: { actor: 'isla' },
          headers: { Origin: origin },
        })
      ).status,
      403,
    );
  // Fetch deliberately rewrites Host. Use actual HTTP bytes for this boundary.
  const foreignHost = await new Promise((resolve, reject) => {
    const request = httpRequest(
      {
        hostname: '127.0.0.1',
        port: app.port,
        path: '/api/documents/session',
        method: 'POST',
        headers: {
          Host: 'example.com',
          'X-Lab-Request': '1',
          'Content-Type': 'application/json',
        },
      },
      (response) => {
        response.resume();
        response.on('end', () => resolve(response.statusCode));
      },
    );
    request.on('error', reject);
    request.end(JSON.stringify({ actor: 'isla' }));
  });
  assert.equal(foreignHost, 403);
  const sameOrigin = await app.request('/session', {
    method: 'POST',
    body: { actor: 'isla' },
    headers: { Origin: `http://127.0.0.1:${app.port}` },
  });
  assert.equal(sameOrigin.status, 200);
  assert.equal(
    (await app.request('-unrelated')).body,
    'Outside document handler',
  );
});

void test('demo identities receive server-held sessions with defensive cookie and response headers', async (t) => {
  const { app } = await fixture(t);
  const { cookie, result } = await session(app);
  assert.equal(result.body.tenant, 'isla-studio');
  assert.match(result.headers.get('set-cookie'), /HttpOnly/);
  assert.match(result.headers.get('set-cookie'), /SameSite=Strict/);
  assert.match(result.headers.get('set-cookie'), /Path=\/api\/documents/);
  assert.match(cookie, /^lab-document-session=[a-f0-9]{64}$/);
  const list = await app.request('', { cookie });
  assert.equal(list.status, 200);
  assert.equal(list.headers.get('cache-control'), 'no-store');
  assert.equal(list.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(list.body.identity.actor, 'Isla reviewer');
  for (const actor of [
    '__proto__',
    'constructor',
    'unknown',
    null,
    {},
    ['isla'],
  ])
    assert.equal(
      (await app.request('/session', { method: 'POST', body: { actor } }))
        .status,
      400,
    );
});

void test('tenant-scoped list, get, update and approval deny the other workspace', async (t) => {
  const { app } = await fixture(t);
  const isla = await session(app, 'isla'),
    norte = await session(app, 'norte');
  const a = await create(app, isla.cookie, 'clean', 'same-key');
  const b = await create(app, norte.cookie, 'clean', 'same-key');
  assert.notEqual(a.id, b.id);
  for (const [owner, own, foreign] of [
    [isla, a, b],
    [norte, b, a],
  ]) {
    const list = await app.request('', { cookie: owner.cookie });
    assert.deepEqual(
      list.body.cases.map((c) => c.id),
      [own.id],
    );
    assert.equal(
      (await app.request(`/${own.id}`, { cookie: owner.cookie })).status,
      200,
    );
    const read = await app.request(`/${foreign.id}`, { cookie: owner.cookie });
    assert.equal(read.status, 404);
    assert.equal(read.body.case, undefined);
    assert.equal(
      (await patch(app, owner.cookie, foreign, { amountCents: 1 })).status,
      404,
    );
    assert.equal((await approve(app, owner.cookie, foreign)).status, 404);
  }
  assert.equal(
    (await app.request(`/${a.id}`, { cookie: isla.cookie })).body.case.revision,
    1,
  );
});

void test('duplicate concurrent creation is idempotent and a changed fixture conflicts', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  const results = await Promise.all(
    Array.from({ length: 16 }, () =>
      app.request('', {
        method: 'POST',
        cookie,
        body: { fixture: 'conflict', requestKey: 'retry-key' },
      }),
    ),
  );
  assert.ok(results.every((r) => r.status === 200));
  assert.equal(new Set(results.map((r) => r.body.case.id)).size, 1);
  assert.ok(
    results.every(
      (r) => r.body.case.revision === 1 && r.body.case.events.length === 1,
    ),
  );
  const conflict = await app.request('', {
    method: 'POST',
    cookie,
    body: { fixture: 'clean', requestKey: 'retry-key' },
  });
  assert.equal(conflict.status, 409);
  const list = await app.request('', { cookie });
  assert.equal(list.body.cases.length, 1);
  assert.equal(list.body.cases[0].fixture, 'conflict');
});

void test('HTTP parsing and schemas reject invalid bodies without creating records', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  for (const raw of ['{bad', 'null', '[]', '"text"'])
    assert.equal(
      (await app.request('', { method: 'POST', cookie, raw })).status,
      400,
    );
  assert.equal(
    (
      await app.request('', {
        method: 'POST',
        cookie,
        raw: JSON.stringify({ fixture: 'clean', requestKey: 'mime' }),
        headers: { 'Content-Type': 'text/plain' },
      })
    ).status,
    415,
  );
  assert.equal(
    (
      await app.request('', {
        method: 'POST',
        cookie,
        raw: JSON.stringify({ padding: 'x'.repeat(5000) }),
      })
    ).status,
    413,
  );
  for (const body of [
    {},
    { fixture: 'unknown', requestKey: 'a' },
    { fixture: '__proto__', requestKey: 'a' },
    { fixture: 'clean', requestKey: '' },
    { fixture: 'clean', requestKey: '../unsafe' },
    { fixture: 'clean', requestKey: 'x'.repeat(101) },
    { fixture: 'clean', requestKey: 1 },
    { fixture: 'clean', requestKey: 'spoof', tenant: 'norte-studio' },
    { fixture: 'clean', requestKey: 'spoof', actor: 'Norte reviewer' },
  ])
    assert.equal(
      (await app.request('', { method: 'POST', cookie, body })).status,
      400,
    );
  assert.equal((await app.request('', { cookie })).body.cases.length, 0);
});

void test('corrections require integer amounts, verification flags and exact revision types', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  const record = await create(app, cookie);
  for (const amountCents of [-1, 1.5, 100000001, '130000', null])
    assert.equal(
      (await patch(app, cookie, record, { amountCents })).status,
      400,
    );
  for (const verified of ['true', 1, null])
    assert.equal((await patch(app, cookie, record, { verified })).status, 400);
  for (const revision of [0, -1, 1.5, '1', null])
    assert.equal((await patch(app, cookie, record, { revision })).status, 400);
  assert.equal(
    (await patch(app, cookie, record, { approved: true })).status,
    400,
  );
  assert.equal(
    (await patch(app, cookie, record, { printedCents: 1 })).status,
    400,
  );
  const current = (await app.request(`/${record.id}`, { cookie })).body.case;
  assert.equal(current.revision, 1);
  assert.equal(current.events.length, 1);
  assert.equal(current.printedCents, 130000);
});

void test('concurrent edits use compare-and-swap and stale edits cannot overwrite a newer revision', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  const record = await create(app, cookie, 'conflict');
  const updates = await Promise.all([
    patch(app, cookie, record, { amountCents: 130000, verified: true }),
    patch(app, cookie, record, { amountCents: 120000, verified: false }),
  ]);
  assert.deepEqual(
    updates.map((r) => r.status).sort((a, b) => a - b),
    [200, 409],
  );
  const winner = updates.find((r) => r.status === 200).body.case;
  assert.equal(winner.revision, 2);
  assert.equal(
    (await patch(app, cookie, record, { amountCents: 1 })).status,
    409,
  );
  assert.equal((await approve(app, cookie, record)).status, 409);
  const current = (await app.request(`/${record.id}`, { cookie })).body.case;
  assert.equal(current.amountCents, winner.amountCents);
  assert.equal(current.events.length, 2);
});

void test('approval requires all independent checks and cannot be forced by a verification checkbox', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  for (const name of ['conflict', 'uncertain', 'missing']) {
    const record = await create(app, cookie, name, name);
    assert.equal(record.status, 'review');
    assert.equal((await approve(app, cookie, record)).status, 422);
    const marked = await patch(app, cookie, record, { verified: true });
    assert.equal(marked.status, 200);
    const result = await approve(app, cookie, marked.body.case);
    assert.equal(result.status, name === 'uncertain' ? 200 : 422);
  }
});

void test('approval records its reviewed revision and later edits invalidate it', async (t) => {
  const { app } = await fixture(t),
    { cookie } = await session(app);
  const original = await create(app, cookie, 'conflict');
  const correction = await patch(app, cookie, original, {
    amountCents: 130000,
    verified: true,
  });
  assert.equal(correction.body.case.status, 'ready');
  const approved = await approve(app, cookie, correction.body.case);
  assert.equal(approved.status, 200);
  assert.equal(approved.body.case.status, 'approved');
  assert.equal(approved.body.case.events.at(-1).reviewedRevision, 2);
  assert.equal(approved.body.case.events.at(-1).revision, 3);
  assert.equal((await approve(app, cookie, approved.body.case)).status, 409);
  const edited = await patch(app, cookie, approved.body.case, {
    amountCents: 120000,
  });
  assert.equal(edited.body.case.approved, false);
  assert.equal(edited.body.case.status, 'review');
  assert.equal(edited.body.case.revision, 4);
  assert.equal(edited.body.case.events.at(-1).actor, 'Isla reviewer');
  assert.equal((await approve(app, cookie, edited.body.case)).status, 422);
});

void test('state and idempotency survive restart; old in-memory sessions do not', async (t) => {
  const { app, restart } = await fixture(t),
    { cookie } = await session(app);
  const original = await create(app, cookie, 'clean', 'persisted-key');
  const approved = await approve(app, cookie, original);
  assert.equal(approved.status, 200);
  await app.close();
  const restarted = await restart();
  assert.equal((await restarted.request('', { cookie })).status, 401);
  const fresh = await session(restarted);
  const stored = (
    await restarted.request(`/${original.id}`, { cookie: fresh.cookie })
  ).body.case;
  assert.deepEqual(stored, approved.body.case);
  const replay = await create(
    restarted,
    fresh.cookie,
    'clean',
    'persisted-key',
  );
  assert.deepEqual(replay, stored);
  const other = await session(restarted, 'norte');
  assert.equal(
    (await restarted.request(`/${original.id}`, { cookie: other.cookie }))
      .status,
    404,
  );
});
