import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer, request as httpRequest } from 'node:http';
import { createInvestigationHandler } from './investigation-service.mjs';

async function start(options = {}) {
  const server = createServer(async (req, res) => {
    const handled = await handler(
      req,
      res,
      new URL(req.url, 'http://localhost').pathname,
    );
    if (!handled) {
      res.writeHead(404);
      res.end();
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const handler = createInvestigationHandler({ port, ...options });
  return {
    port,
    server,
    async close() {
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
      handler.close();
    },
    async request(
      route,
      { method = 'GET', cookie, body, headers = {}, raw, omitLab = false } = {},
    ) {
      return new Promise((resolve, reject) => {
        const req = httpRequest(
          `http://127.0.0.1:${port}/api/investigation${route}`,
          {
            method,
            signal: AbortSignal.timeout(5000),
            headers: {
              ...(!omitLab ? { 'X-Lab-Request': '1' } : {}),
              ...(method !== 'GET'
                ? { 'Content-Type': 'application/json' }
                : {}),
              ...(cookie ? { Cookie: cookie } : {}),
              ...headers,
            },
          },
          (res) => {
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('error', reject);
            res.on('end', () => {
              const responseHeaders = new Headers(
                Object.entries(res.headers)
                  .filter(([, value]) => value !== undefined)
                  .map(([key, value]) => [
                    key,
                    Array.isArray(value) ? value.join(', ') : value,
                  ]),
              );
              resolve({
                status: res.statusCode,
                data: JSON.parse(Buffer.concat(chunks).toString()),
                headers: responseHeaders,
                cookie: responseHeaders.get('set-cookie')?.split(';')[0],
              });
            });
          },
        );
        req.on('error', reject);
        req.end(
          method === 'GET' ? undefined : (raw ?? JSON.stringify(body ?? {})),
        );
      });
    },
  };
}

void test('a phone host is explicit; foreign host, cross-origin and missing request header are rejected', async (t) => {
  const app = await start({ host: '100.64.0.2' });
  t.after(() => app.close());
  const host = `100.64.0.2:${app.port}`;
  for (const headers of [
    {},
    { Host: host, Origin: 'https://attacker.example' },
    { Host: host, 'Sec-Fetch-Site': 'cross-site' },
  ])
    assert.equal(
      (await app.request('/session', { method: 'POST', headers })).status,
      403,
    );
  assert.equal(
    (
      await app.request('/session', {
        method: 'POST',
        headers: { Host: host },
        omitLab: true,
      })
    ).status,
    403,
  );
  const allowed = await app.request('/session', {
    method: 'POST',
    headers: { Host: host, Origin: `http://${host}` },
  });
  assert.equal(allowed.status, 200);
  assert.equal(allowed.data.case.amountCents, 180000);
  assert.equal(allowed.headers.get('cache-control'), 'no-store');
  assert.match(
    allowed.headers.get('set-cookie'),
    /HttpOnly; SameSite=Strict; Path=\/api\/investigation/,
  );
});

void test('each visitor owns an isolated case and session retries resume the same case', async (t) => {
  const app = await start();
  t.after(() => app.close());
  const a = await app.request('/session', { method: 'POST' });
  const b = await app.request('/session', { method: 'POST' });
  assert.notEqual(a.data.case.id, b.data.case.id);
  assert.notEqual(a.data.case.tenant, b.data.case.tenant);
  const again = await app.request('/session', {
    method: 'POST',
    cookie: a.cookie,
  });
  assert.equal(again.data.case.id, a.data.case.id);
  for (const { method, suffix, body } of [
    { method: 'GET', suffix: '', body: undefined },
    { method: 'GET', suffix: '/receipt', body: undefined },
    {
      method: 'PATCH',
      suffix: '',
      body: { revision: 1, amountCents: 130000, verified: true },
    },
    { method: 'POST', suffix: '/approve', body: { revision: 1 } },
  ]) {
    assert.equal(
      (
        await app.request('/' + a.data.case.id + suffix, {
          method,
          cookie: b.cookie,
          body,
        })
      ).status,
      404,
    );
  }
  assert.equal((await app.request('/' + a.data.case.id)).status, 401);
});

void test('the complete live correction, approval and stale-write rejection produces real event evidence', async (t) => {
  const app = await start();
  t.after(() => app.close());
  const first = await app.request('/session', { method: 'POST' });
  const cookie = first.cookie,
    path = '/' + first.data.case.id;
  assert.equal(first.data.case.printedCents, 130000);
  assert.equal(first.data.case.confidence, 97);
  assert.equal(
    (
      await app.request(path + '/approve', {
        cookie,
        method: 'POST',
        body: { revision: 1 },
      })
    ).status,
    422,
  );
  const fixed = await app.request(path, {
    cookie,
    method: 'PATCH',
    body: { revision: 1, amountCents: 130000, verified: true },
  });
  assert.equal(fixed.status, 200);
  assert.equal(fixed.data.case.status, 'ready');
  const approved = await app.request(path + '/approve', {
    cookie,
    method: 'POST',
    body: { revision: 2 },
  });
  assert.equal(approved.data.case.status, 'approved');
  assert.equal(approved.data.case.events.at(-1).reviewedRevision, 2);
  const stale = await app.request(path, {
    cookie,
    method: 'PATCH',
    body: { revision: 1, amountCents: 180000, verified: false },
  });
  assert.equal(stale.status, 409);
  const receipt = await app.request(path + '/receipt', { cookie });
  assert.equal(receipt.data.case.amountCents, 130000);
  assert.equal(receipt.data.case.revision, 3);
  assert.equal(receipt.data.case.status, 'approved');
  const recorded = receipt.data.requests.find(
    (r) => r.id === stale.data.execution.requestId,
  );
  assert.equal(recorded.status, 409);
  assert.equal(recorded.method, 'PATCH');
  assert.equal(receipt.data.execution.engine, 'Node.js / SQLite');
  assert.equal(
    JSON.stringify(receipt.data).includes(cookie.split('=')[1]),
    false,
  );
  const edited = await app.request(path, {
    cookie,
    method: 'PATCH',
    body: { revision: 3, amountCents: 130000, verified: true },
  });
  assert.equal(edited.data.case.approved, false);
  assert.equal(edited.data.case.revision, 4);
});

void test('concurrent updates admit one revision and preserve the winner', async (t) => {
  const app = await start();
  t.after(() => app.close());
  const first = await app.request('/session', { method: 'POST' });
  const path = '/' + first.data.case.id,
    cookie = first.cookie;
  const results = await Promise.all(
    [130000, 140000].map((amountCents) =>
      app.request(path, {
        method: 'PATCH',
        cookie,
        body: { revision: 1, amountCents, verified: true },
      }),
    ),
  );
  assert.deepEqual(
    results.map((r) => r.status).sort((a, b) => a - b),
    [200, 409],
  );
  const stored = await app.request(path, { cookie });
  assert.equal(
    stored.data.case.amountCents,
    results.find((r) => r.status === 200).data.case.amountCents,
  );
  assert.equal(stored.data.case.revision, 2);
});

void test('invalid schemas and large bodies never change the case', async (t) => {
  const app = await start();
  t.after(() => app.close());
  assert.equal(
    (
      await app.request('/session', {
        method: 'POST',
        body: { tenant: 'someone-else' },
      })
    ).status,
    400,
  );
  const first = await app.request('/session', { method: 'POST' });
  const path = '/' + first.data.case.id,
    cookie = first.cookie;
  for (const body of [
    null,
    [],
    { revision: 1 },
    { revision: 1, amountCents: 130000.5, verified: true },
    { revision: 1, amountCents: 130000, verified: 'yes' },
    { revision: 1, amountCents: 130000, verified: true, tenant: 'foreign' },
  ])
    assert.equal(
      (
        await app.request(path, {
          cookie,
          method: 'PATCH',
          body,
          raw: body === null ? 'null' : undefined,
        })
      ).status,
      400,
    );
  assert.equal(
    (await app.request(path, { cookie, method: 'PATCH', raw: '{bad' })).status,
    400,
  );
  assert.equal(
    (
      await app.request(path, {
        cookie,
        method: 'PATCH',
        raw: 'x'.repeat(4097),
      })
    ).status,
    413,
  );
  assert.equal(
    (
      await app.request(path, {
        cookie,
        method: 'PATCH',
        headers: { 'Content-Type': 'text/plain' },
      })
    ).status,
    415,
  );
  assert.equal((await app.request(path, { cookie })).data.case.revision, 1);
});

void test('reset only replaces its own case; expiry cleans session capacity and invalidates old cookies', async (t) => {
  let clock = Date.now();
  const app = await start({
    now: () => clock,
    sessionTtlMs: 1000,
    maxSessions: 2,
  });
  t.after(() => app.close());
  const a = await app.request('/session', { method: 'POST' });
  const b = await app.request('/session', { method: 'POST' });
  assert.equal((await app.request('/session', { method: 'POST' })).status, 429);
  const reset = await app.request('/reset', {
    method: 'POST',
    cookie: a.cookie,
  });
  assert.notEqual(reset.data.case.id, a.data.case.id);
  assert.equal(
    (await app.request('/' + a.data.case.id, { cookie: a.cookie })).status,
    404,
  );
  assert.equal(
    (await app.request('/' + b.data.case.id, { cookie: b.cookie })).status,
    200,
  );
  clock += 1001;
  assert.equal(
    (await app.request('/' + b.data.case.id, { cookie: b.cookie })).status,
    401,
  );
  assert.equal((await app.request('/session', { method: 'POST' })).status, 200);
});

void test('per-session request limits recover after their window without erasing the case', async (t) => {
  let clock = Date.now();
  const app = await start({ now: () => clock, rateLimit: 3 });
  t.after(() => app.close());
  const first = await app.request('/session', { method: 'POST' });
  const path = '/' + first.data.case.id,
    cookie = first.cookie;
  assert.equal((await app.request(path, { cookie })).status, 200);
  assert.equal((await app.request(path, { cookie })).status, 200);
  assert.equal((await app.request(path, { cookie })).status, 429);
  clock += 60_001;
  assert.equal(
    (await app.request(path, { cookie })).data.case.id,
    first.data.case.id,
  );
});

void test('a reset crossing expiry cannot recreate a case after session cleanup', async (t) => {
  let clock = Date.now();
  const app = await start({
    now: () => clock,
    sessionTtlMs: 1000,
    maxSessions: 1,
  });
  t.after(() => app.close());
  const first = await app.request('/session', { method: 'POST' });
  const bodyStarted = new Promise((resolve) => {
    app.server.once('request', (req) => req.once('data', resolve));
  });
  let pending;
  const completed = new Promise((resolve, reject) => {
    pending = httpRequest(
      `http://127.0.0.1:${app.port}/api/investigation/reset`,
      {
        method: 'POST',
        signal: AbortSignal.timeout(5000),
        headers: {
          'X-Lab-Request': '1',
          'Content-Type': 'application/json',
          Cookie: first.cookie,
        },
      },
      (res) => {
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('error', reject);
        res.on('end', () =>
          resolve({
            status: res.statusCode,
            data: JSON.parse(Buffer.concat(chunks).toString()),
          }),
        );
      },
    );
    pending.on('error', reject);
    pending.write('{');
  });
  await bodyStarted;
  clock += 1001;
  assert.equal(
    (await app.request('/' + first.data.case.id, { cookie: first.cookie }))
      .status,
    401,
  );
  pending.end('}');
  const reset = await completed;
  assert.equal(reset.status, 401);
  assert.equal(Object.hasOwn(reset.data, 'case'), false);
  const restarted = await app.request('/session', {
    method: 'POST',
    cookie: first.cookie,
  });
  assert.equal(restarted.status, 200);
  assert.notEqual(restarted.cookie, first.cookie);
  assert.notEqual(restarted.data.case.id, first.data.case.id);
  assert.equal(
    (
      await app.request('/' + restarted.data.case.id, {
        cookie: restarted.cookie,
      })
    ).status,
    200,
  );
  assert.equal((await app.request('/session', { method: 'POST' })).status, 429);
});

void test('receipt snapshots contain at most 80 prior requests without appending to the snapshot', async (t) => {
  const app = await start({ rateLimit: 1000 });
  t.after(() => app.close());
  const first = await app.request('/session', { method: 'POST' });
  const path = '/' + first.data.case.id;
  const reads = [];
  for (let i = 0; i < 82; i++) {
    const read = await app.request(path, { cookie: first.cookie });
    assert.equal(read.status, 200);
    reads.push(read.data.execution.requestId);
  }
  const receipt = await app.request(path + '/receipt', {
    cookie: first.cookie,
  });
  assert.equal(receipt.status, 200);
  assert.equal(receipt.data.requests.length, 80);
  assert.deepEqual(
    receipt.data.requests.map((entry) => entry.id),
    reads.slice(-80),
  );
  assert.equal(
    receipt.data.requests.some(
      (entry) => entry.id === receipt.data.execution.requestId,
    ),
    false,
  );
  const next = await app.request(path + '/receipt', { cookie: first.cookie });
  assert.equal(next.data.requests.length, 80);
  assert.equal(next.data.requests.at(-1).id, receipt.data.execution.requestId);
});
