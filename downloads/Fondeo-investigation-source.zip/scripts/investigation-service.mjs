import { randomBytes, randomUUID } from 'node:crypto';
import { createDocumentStore } from './document-workbench.mjs';

// Deliberately separate from the original, disk-backed workspace. Every visitor
// receives one private synthetic case; this service never opens that database.
export function createInvestigationHandler({
  port = 4317,
  host = '127.0.0.1',
  now = Date.now,
  sessionTtlMs = 60 * 60 * 1000,
  maxSessions = 256,
  rateLimit = 60,
} = {}) {
  const store = createDocumentStore(':memory:');
  const sessions = new Map();
  const hosts = new Set([`${host}:${port}`]);
  if (host === '127.0.0.1') hosts.add(`localhost:${port}`);
  const sweep = () => {
    for (const [token, session] of sessions)
      if (session.expiresAt <= now()) {
        store.deleteTenant(session.tenant);
        sessions.delete(token);
      }
  };
  const cleanup = setInterval(sweep, 60_000);
  cleanup.unref();
  const fail = (message, status = 400) => {
    throw Object.assign(new Error(message), { status });
  };
  const fields = (value, keys) => {
    if (
      !value ||
      typeof value !== 'object' ||
      Array.isArray(value) ||
      Object.keys(value).length !== keys.length ||
      keys.some((key) => !Object.hasOwn(value, key))
    )
      fail('Provide exactly the fields required for this operation.');
  };
  const handler = async (req, res, pathname) => {
    if (
      pathname !== '/api/investigation' &&
      !pathname.startsWith('/api/investigation/')
    )
      return false;
    const requestId = randomUUID();
    const at = new Date(now()).toISOString();
    let session;
    const respond = (status, body, headers = {}) => {
      if (session) {
        session.requests.push({
          id: requestId,
          method: req.method,
          operation: pathname,
          status,
          at,
          ...(body.case ? { revision: body.case.revision } : {}),
          ...(body.error ? { note: body.error } : {}),
        });
        session.requests = session.requests.slice(-80);
      }
      res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'X-Request-Id': requestId,
        ...headers,
      });
      res.end(
        JSON.stringify({
          ...body,
          execution: {
            mode: 'live',
            engine: 'Node.js / SQLite',
            requestId,
            at,
          },
        }),
      );
    };
    try {
      if (
        !hosts.has(req.headers.host) ||
        req.headers['x-lab-request'] !== '1' ||
        (req.headers.origin &&
          req.headers.origin !== `http://${req.headers.host}`) ||
        req.headers['sec-fetch-site'] === 'cross-site'
      )
        fail('Open this example from the portfolio preview.', 403);
      sweep();
      const token = /(?:^|;\s*)lab-investigation=([a-f0-9]{64})(?:;|$)/.exec(
        req.headers.cookie || '',
      )?.[1];
      session = sessions.get(token);
      if (session) {
        if (now() - session.rateStart >= 60_000) {
          session.rateStart = now();
          session.rateCount = 0;
        }
        session.rateCount += 1;
        if (session.rateCount > rateLimit)
          fail(
            'This example is receiving too many requests. Wait a minute and try again.',
            429,
          );
      }
      let input = {};
      if (req.method !== 'GET') {
        if (
          req.headers['content-type']?.split(';')[0].trim().toLowerCase() !==
          'application/json'
        )
          fail('Send application/json.', 415);
        const chunks = [];
        let bytes = 0;
        for await (const chunk of req) {
          bytes += chunk.length;
          if (bytes > 4096) fail('Keep example requests below 4 KB.', 413);
          chunks.push(chunk);
        }
        try {
          input = JSON.parse(Buffer.concat(chunks).toString());
        } catch {
          fail('Send valid JSON.');
        }
      }
      // Reading a streamed body can cross expiry while another request or the
      // cleanup timer removes the tenant. Reacquire identity before operating.
      sweep();
      session = sessions.get(token);
      if (pathname === '/api/investigation/session' && req.method === 'POST') {
        fields(input, []);
        if (session) {
          respond(200, {
            case: store.get(session.caseId, session.tenant),
            session: { expiresAt: session.expiresAt },
          });
          return true;
        }
        if (sessions.size >= maxSessions)
          fail(
            'The example is busy. Try again later, or use the browser example.',
            429,
          );
        const nextToken = randomBytes(32).toString('hex');
        const tenant = `visitor-${randomUUID()}`;
        const record = store.create(
          tenant,
          'Demo reviewer',
          'conflict',
          'first-example',
        );
        session = {
          tenant,
          caseId: record.id,
          expiresAt: now() + sessionTtlMs,
          rateStart: now(),
          rateCount: 1,
          requests: [],
          updates: 0,
        };
        sessions.set(nextToken, session);
        respond(
          200,
          { case: record, session: { expiresAt: session.expiresAt } },
          {
            'Set-Cookie': `lab-investigation=${nextToken}; HttpOnly; SameSite=Strict; Path=/api/investigation; Max-Age=${Math.floor(sessionTtlMs / 1000)}`,
          },
        );
        return true;
      }
      if (!session)
        fail(
          'This example session expired. Start a new example to continue.',
          401,
        );
      if (pathname === '/api/investigation/reset' && req.method === 'POST') {
        fields(input, []);
        store.deleteTenant(session.tenant);
        const record = store.create(
          session.tenant,
          'Demo reviewer',
          'conflict',
          randomUUID(),
        );
        session.caseId = record.id;
        session.requests = [];
        session.updates = 0;
        respond(200, {
          case: record,
          session: { expiresAt: session.expiresAt },
        });
        return true;
      }
      const match =
        /^\/api\/investigation\/([a-f0-9-]{36})(?:\/(approve|receipt))?$/.exec(
          pathname,
        );
      if (!match) fail('Unknown investigation operation.', 404);
      const record = store.get(match[1], session.tenant);
      if (!record || record.id !== session.caseId)
        fail('This example was not found in your session.', 404);
      if (req.method === 'GET' && (!match[2] || match[2] === 'receipt')) {
        respond(200, {
          case: record,
          ...(match[2] === 'receipt'
            ? {
                requests: session.requests.slice(-80),
                limits:
                  'Synthetic invoice and extraction. Actual in-memory SQLite execution; no OCR, cloud call, or real financial approval. This temporary session expires after one hour.',
              }
            : {}),
        });
      } else if (
        (req.method === 'PATCH' && !match[2]) ||
        (req.method === 'POST' && match[2] === 'approve')
      ) {
        const review = match[2] === 'approve';
        fields(
          input,
          review ? ['revision'] : ['revision', 'amountCents', 'verified'],
        );
        if (session.updates >= 100)
          fail(
            'This example has reached its revision limit. Reset it to continue.',
            429,
          );
        const next = store.update(
          session.tenant,
          'Demo reviewer',
          record.id,
          input,
          review,
        );
        session.updates += 1;
        respond(200, { case: next });
      } else fail('Unsupported investigation operation.', 405);
    } catch (error) {
      respond(error.status || 500, {
        error: error.status
          ? error.message
          : 'The example service could not finish. Keep your result and try reconnecting.',
      });
    }
    return true;
  };
  handler.close = () => {
    clearInterval(cleanup);
    store.close();
  };
  return handler;
}
