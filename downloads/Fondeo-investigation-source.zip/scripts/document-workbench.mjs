import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomUUID } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import path from 'node:path';

import {
  DOCUMENT_FIXTURES,
  decision,
  createInvoiceRecord,
  applyInvoiceRevision,
} from '../lib/document-rules.mjs';
export { DOCUMENT_FIXTURES, decision } from '../lib/document-rules.mjs';
export function createDocumentStore(
  filename = '.local/document-workbench.sqlite',
) {
  if (filename !== ':memory:')
    mkdirSync(path.dirname(filename), { recursive: true });
  const db = new DatabaseSync(filename);
  db.exec(
    'PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,request_key TEXT NOT NULL,fixture TEXT NOT NULL,body TEXT NOT NULL,UNIQUE(tenant,request_key));',
  );
  const get = (id, tenant) => {
    const row = db
      .prepare('SELECT body FROM cases WHERE id=? AND tenant=?')
      .get(id, tenant);
    return row ? JSON.parse(row.body) : null;
  };
  const decorate = (record) => ({
    ...record,
    ...decision(record),
    status: record.approved ? 'approved' : decision(record).status,
  });
  return {
    close: () => db.close(),
    deleteTenant: (tenant) =>
      db.prepare('DELETE FROM cases WHERE tenant=?').run(tenant),
    list: (tenant) =>
      db
        .prepare(
          'SELECT body FROM cases WHERE tenant=? ORDER BY rowid DESC LIMIT 30',
        )
        .all(tenant)
        .map((r) => decorate(JSON.parse(r.body))),
    get: (id, tenant) => {
      const record = get(id, tenant);
      return record && decorate(record);
    },
    create(tenant, actor, fixture, requestKey) {
      if (
        typeof fixture !== 'string' ||
        !Object.hasOwn(DOCUMENT_FIXTURES, fixture) ||
        typeof requestKey !== 'string' ||
        !/^[\w-]{1,100}$/.test(requestKey)
      )
        throw Object.assign(
          new Error('Choose a supported fixture and a valid request key.'),
          { status: 400 },
        );
      db.exec('BEGIN IMMEDIATE');
      try {
        const prior = db
          .prepare(
            'SELECT fixture, body FROM cases WHERE tenant=? AND request_key=?',
          )
          .get(tenant, requestKey);
        if (prior) {
          if (prior.fixture !== fixture)
            throw Object.assign(
              new Error('That request key belongs to a different document.'),
              { status: 409 },
            );
          db.exec('COMMIT');
          return decorate(JSON.parse(prior.body));
        }
        const record = createInvoiceRecord({
          id: randomUUID(),
          tenant,
          fixture,
          actor,
          at: new Date().toISOString(),
        });
        db.prepare('INSERT INTO cases VALUES(?,?,?,?,?)').run(
          record.id,
          tenant,
          requestKey,
          fixture,
          JSON.stringify(record),
        );
        db.exec('COMMIT');
        return decorate(record);
      } catch (error) {
        if (db.isTransaction) db.exec('ROLLBACK');
        throw error;
      }
    },
    update(tenant, actor, id, input, review = false) {
      db.exec('BEGIN IMMEDIATE');
      try {
        const record = get(id, tenant);
        if (!record)
          throw Object.assign(
            new Error('Document not found in this workspace.'),
            { status: 404 },
          );
        const next = applyInvoiceRevision(
          record,
          input,
          actor,
          new Date().toISOString(),
          review,
        );
        db.prepare('UPDATE cases SET body=? WHERE id=? AND tenant=?').run(
          JSON.stringify(next),
          id,
          tenant,
        );
        db.exec('COMMIT');
        return decorate(next);
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
  };
}
export function createDocumentHandler({ port = 4317, filename } = {}) {
  const store = createDocumentStore(filename),
    sessions = new Map();
  const actors = {
    isla: {
      tenant: 'isla-studio',
      actor: 'Isla reviewer',
      label: 'Isla Studio',
    },
    norte: {
      tenant: 'norte-studio',
      actor: 'Norte reviewer',
      label: 'Norte Studio',
    },
  };
  const send = (res, code, body, headers = {}) => {
    res.writeHead(code, {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...headers,
    });
    res.end(JSON.stringify(body));
  };
  const exactFields = (input, fields) => {
    if (
      Object.keys(input).some((key) => !fields.includes(key)) ||
      fields.some((key) => !Object.hasOwn(input, key))
    )
      throw Object.assign(
        new Error('Provide exactly the fields required for this operation.'),
        { status: 400 },
      );
  };
  const handler = async (req, res, pathname) => {
    if (
      pathname !== '/api/documents' &&
      !pathname.startsWith('/api/documents/')
    )
      return false;
    const allowed = [`localhost:${port}`, `127.0.0.1:${port}`];
    if (
      !allowed.includes(req.headers.host) ||
      req.headers['x-lab-request'] !== '1' ||
      (req.headers.origin &&
        !allowed.some((h) => req.headers.origin === `http://${h}`))
    ) {
      send(res, 403, {
        error: 'Open this instrument from the local portfolio.',
      });
      return true;
    }
    try {
      let input = {};
      if (req.method !== 'GET') {
        if (
          req.headers['content-type']?.split(';')[0].trim().toLowerCase() !==
          'application/json'
        ) {
          send(res, 415, { error: 'Send application/json.' });
          return true;
        }
        const chunks = [];
        let size = 0;
        for await (const chunk of req) {
          size += chunk.length;
          if (size > 4096) {
            send(res, 413, { error: 'Request too large.' });
            return true;
          }
          chunks.push(chunk);
        }
        try {
          input = JSON.parse(Buffer.concat(chunks).toString());
        } catch {
          send(res, 400, { error: 'Send valid JSON.' });
          return true;
        }
        if (!input || typeof input !== 'object' || Array.isArray(input)) {
          send(res, 400, { error: 'Send a request object.' });
          return true;
        }
      }
      if (pathname === '/api/documents/session' && req.method === 'POST') {
        exactFields(input, ['actor']);
        if (
          typeof input.actor !== 'string' ||
          !Object.hasOwn(actors, input.actor)
        ) {
          send(res, 400, { error: 'Choose a demo workspace.' });
          return true;
        }
        for (const [key, value] of sessions)
          if (value.expires < Date.now()) sessions.delete(key);
        if (sessions.size >= 1000) {
          send(res, 429, { error: 'Too many active demo sessions.' });
          return true;
        }
        const session = randomBytes(32).toString('hex'),
          identity = actors[input.actor];
        sessions.set(session, {
          ...identity,
          expires: Date.now() + 8 * 3600000,
        });
        send(res, 200, identity, {
          'Set-Cookie': `lab-document-session=${session}; HttpOnly; SameSite=Strict; Path=/api/documents; Max-Age=28800`,
        });
        return true;
      }
      const token = /(?:^|;\s*)lab-document-session=([a-f0-9]{64})(?:;|$)/.exec(
        req.headers.cookie || '',
      )?.[1];
      const identity = sessions.get(token);
      if (!identity || identity.expires < Date.now()) {
        send(res, 401, { error: 'Choose a demo workspace to begin.' });
        return true;
      }
      if (
        req.headers['x-lab-workspace'] &&
        req.headers['x-lab-workspace'] !== identity.tenant
      ) {
        send(res, 409, {
          error:
            'The active workspace changed in another tab. Reconnect this workspace before continuing.',
        });
        return true;
      }
      if (pathname === '/api/documents' && req.method === 'GET')
        send(res, 200, { identity, cases: store.list(identity.tenant) });
      else if (pathname === '/api/documents' && req.method === 'POST') {
        exactFields(input, ['fixture', 'requestKey']);
        send(res, 200, {
          case: store.create(
            identity.tenant,
            identity.actor,
            input.fixture,
            input.requestKey,
          ),
        });
      } else {
        const match = /^\/api\/documents\/([a-f0-9-]{36})(\/approve)?$/.exec(
          pathname,
        );
        if (!match) {
          send(res, 404, { error: 'Unknown document operation.' });
          return true;
        }
        if (req.method === 'GET' && !match[2]) {
          const record = store.get(match[1], identity.tenant);
          send(
            res,
            record ? 200 : 404,
            record
              ? { case: record }
              : { error: 'Document not found in this workspace.' },
          );
        } else if (
          (req.method === 'PATCH' && !match[2]) ||
          (req.method === 'POST' && match[2])
        ) {
          exactFields(
            input,
            match[2] ? ['revision'] : ['revision', 'amountCents', 'verified'],
          );
          send(res, 200, {
            case: store.update(
              identity.tenant,
              identity.actor,
              match[1],
              input,
              !!match[2],
            ),
          });
        } else send(res, 405, { error: 'Unsupported document operation.' });
      }
    } catch (error) {
      send(res, error.status || 500, {
        error: error.status
          ? error.message
          : 'The local document service could not complete the operation.',
      });
    }
    return true;
  };
  handler.close = () => store.close();
  return handler;
}
