export type InvoiceRule = {
  id: string;
  name: string;
  pass: boolean;
  detail: string;
};
export type InvoiceEvent = {
  at: string;
  actor: string;
  action: string;
  revision: number;
  reviewedRevision?: number;
  amountCents?: number;
};
export type InvoiceRecord = {
  id: string;
  tenant: string;
  fixture: string;
  title: string;
  revision: number;
  amountCents: number;
  printedCents: number;
  confidence: number;
  pagePresent: boolean;
  verified: boolean;
  approved: boolean;
  status: 'ready' | 'review' | 'approved';
  lines: { name: string; cents: number }[];
  events: InvoiceEvent[];
  rules: InvoiceRule[];
  ruleVersion: string;
  provenance: string;
};
export const DOCUMENT_FIXTURES: Record<
  string,
  {
    title: string;
    amountCents: number;
    confidence: number;
    pagePresent: boolean;
  }
>;
export function decision(
  record: Pick<
    InvoiceRecord,
    | 'lines'
    | 'pagePresent'
    | 'amountCents'
    | 'printedCents'
    | 'verified'
    | 'confidence'
  >,
): { rules: InvoiceRule[]; status: 'ready' | 'review' };
export function decorateInvoiceRecord(record: InvoiceRecord): InvoiceRecord;
export function createInvoiceRecord(options: {
  id: string;
  tenant: string;
  fixture?: string;
  actor?: string;
  at: string;
}): InvoiceRecord;
export function applyInvoiceRevision(
  record: InvoiceRecord,
  input: { revision: number; amountCents?: number; verified?: boolean },
  actor: string,
  at: string,
  review?: boolean,
): InvoiceRecord;
