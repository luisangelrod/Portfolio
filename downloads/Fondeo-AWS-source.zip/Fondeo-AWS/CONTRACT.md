# Fondeo AWS extension contract

This directory is an optional source kit. The local portfolio's SQLite document service remains the running product. Nothing here is connected to it or deployed to AWS.

## Trust boundary

`context` is explicitly labeled `explicit-demo-identity`. Anyone permitted to start this demonstration workflow can supply its tenant and actor. Matching that tenant against the document and its references demonstrates scoping logic; it does not authenticate a person, establish document ownership, or provide production tenant isolation.

A future authenticated starter must derive tenant/actor from a verified principal, authorize an immutable document version, resolve its allowed storage location, and construct this envelope on the server. Never copy a client-supplied tenant into a trusted context. The template creates no public HTTP endpoint, starter policy, payment integration, approval service, or document database.

## State contract

| State | Input and output | Failure behavior |
|---|---|---|
| ValidateInputAndScope | `fondeo-input/1` envelope → accepted envelope, denied, or invalid | Strict keys, identifiers, bounded input; mismatch withholds document values |
| ScopeDecision | accepted → extraction; denied → terminal denial | Invalid/default → `InvalidInput` Fail |
| ExtractAuthoredFixture | Gated envelope → `fondeo-extraction/1` | Pure authored data; unexpected exception → `ExecutionFailed` |
| ValidateInvoiceEvidence | Adapter output → deterministic rules and receipt | Invalid schema fails; mismatched tenant/document reference denies |
| ReviewDecision | ready → `ReadyForHumanReview`; review → `NeedsCorrection`; denied → `Denied` | Other status → `InvalidInput` |
| ReadyForHumanReview | Terminal result with `approved: false`, `requiresHumanReview: true` | No automatic approval or external effect |
| NeedsCorrection / Denied | Terminal review/denial result | Workflow success means the decision completed, not that the invoice was approved |

Tasks use JSONPath `Parameters`, optimized `lambda:invoke`, and `OutputPath: $.Payload`. Task deadlines are 15 seconds; Lambda deadlines are 10 seconds; workflow deadline is 120 seconds. Only listed transient Lambda service errors are retried, with two retries, exponential backoff, and full jitter. Business-invalid or review decisions are values and are never retried as infrastructure failures. Catch-all failures terminate explicitly. The local runner traverses these actual state definitions but does not simulate retry timing, AWS error behavior, quotas, or IAM.

## Rule-source contract

Rules are versioned `invoice-integrity-aws-1`. This is a deliberately narrower, independent extension of the local service's `invoice-integrity-1`; it is not claimed to share executable code or enforce identical approval behavior.

| Rule | Source | Interpretation |
|---|---|---|
| source | adapter's source availability | An absent page cannot support approval |
| arithmetic | bounded integer-cent line items and extracted amount | Exact equality, with no float currency rounding |
| source-total | separate source total and extracted amount | The authored fixture has an independent source oracle; a real adapter must not compare an OCR value against a copy of itself |
| confidence | extraction confidence, inclusive threshold 80 | Recognition confidence is an input, not business correctness; 80 is this demo policy, not an AWS recommendation |
| source-reference | tenant, document, immutable document version, extraction operation, and block ID | Both references must match; a bare block ID is insufficient |

The validator rejects empty/duplicate/unbounded line items, non-integer cents including Python booleans, nonfinite confidence, unknown fields, unreviewed provenance, and model-provided `verified` or `approved` flags. The fixture adapter never claims to have called OCR or a model.

The SHA-256 is a deterministic fingerprint of the complete extraction contract, including input identity labels, evidence, and provenance. It detects a changed payload; it is not a signature, an approval, an author identity, or proof that the source data are true. The validator does not persist idempotency keys: repeating a request returns a deterministic result but does not implement execution deduplication or business-side-effect idempotency.

## Adapter replacement boundary

Do not rename the existing mock to imply a live integration. Introduce a separately versioned extraction schema/provenance adapter and explicitly revise validator allowlists and tests.

1. An authenticated intake service resolves a tenant-authorized S3 object and immutable version. Restrict permissions to the required bucket and tenant object scope. Step Functions input should carry references rather than private documents.
2. A Textract adapter chooses the supported synchronous or asynchronous operation for the document. For asynchronous processing, persist the job reference, await completion, consume every result page, and preserve geometry, relationships, operation IDs, and confidence. A successful first API call is not a completed extraction.
3. If Bedrock helps normalize labels or proposes a correction, preserve its input references, model identifier/version, prompt version, raw proposal, and schema validation. Model output cannot set the trusted tenant, independent source value, verification flag, approval, or validation outcome.
4. Route uncertain or contradictory results to a real human review service. Bind an authenticated approval to an exact document/rule revision and action payload; reject stale or changed approvals transactionally. Reuse the local HTTP suite's tenant, revision, and invalidation scenarios as integration requirements.
5. Add persistent execution/intent records and bounded retention before creating external effects. Test duplicate deliveries, interrupted jobs, missing result pages, cross-tenant access, conflicting source versions, model failures, and a replay after restart against the actual services.

The default template intentionally grants no S3, Textract, Bedrock, or database permission. This makes the boundary inspectable; these services remain future adapters, not toggles secretly backed by fixtures.

## Version and lifecycle contract

`build_template.py` embeds the exact Python source in each inline Lambda and the exact parsed ASL definition. Tests detect any generated-template drift. The functions are invoked through immutable `AWS::Lambda::Version` ARNs, with source/configuration hashes in their logical IDs. IAM grants invocation only to those reviewed versions. The Step Functions trust policy is restricted by account and the configured workflow ARN.

Old Lambda versions use Retain policies so a source update does not remove the version referenced by an older workflow. A future operator must remove unused retained versions deliberately. The ResourcePrefix parameter must be unique in the target account/region; function names and log groups use it. Log retention is seven days. The code does not log document inputs; Standard execution history would still contain the synthetic input/output and requires appropriate IAM/retention review before private data are introduced.

## Official references reviewed September 5, 2026

- [Step Functions Task states and JSONPath Parameters](https://docs.aws.amazon.com/step-functions/latest/dg/state-task.html): invocation and data-shaping syntax.
- [Optimized Lambda integration](https://docs.aws.amazon.com/step-functions/latest/dg/connect-lambda.html): parsed Payload and version-qualified invocation permissions.
- [Step Functions error handling](https://docs.aws.amazon.com/step-functions/latest/dg/concepts-error-handling.html): bounded retry, jitter and catch behavior.
- [CloudFormation Lambda Code](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-properties-lambda-function-code.html): Python inline ZipFile packaging and `index` handler module.
- [Lambda runtimes](https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtimes.html): Python 3.13 target. Local tests used Python 3.12.2; the AWS runtime was not exercised.
- [CloudFormation state machine resource](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-stepfunctions-statemachine.html): Standard workflow and DefinitionString properties.
- [Immutable Lambda versions](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-lambda-version.html): version snapshots and Ref ARN behavior.
- [Step Functions role and confused-deputy protection](https://docs.aws.amazon.com/step-functions/latest/dg/procedure-create-iam-role.html): SourceArn and SourceAccount conditions.
- [Textract Block](https://docs.aws.amazon.com/textract/latest/APIReference/API_Block.html): geometry, confidence, relationships and operation-scoped IDs for the future adapter.
- [Textract GetDocumentAnalysis](https://docs.aws.amazon.com/textract/latest/APIReference/API_GetDocumentAnalysis.html): asynchronous result status and pagination for a future real extraction.
- [Bedrock Converse](https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_Converse.html): model/prompt identification and the future normalization interface; no invocation is implemented here.
- [ValidateStateMachineDefinition](https://docs.aws.amazon.com/step-functions/latest/apireference/API_ValidateStateMachineDefinition.html): service-side syntax validation required in a later cloud acceptance pass.
