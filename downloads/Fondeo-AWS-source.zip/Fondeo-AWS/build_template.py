"""Generate CloudFormation from the exact tested Python and ASL sources. No AWS access."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def template():
    resources = {}
    versions = {}
    for name, source, suffix in [("Validator", "validator.py", "validate"), ("Extractor", "extraction_adapter.py", "extract-fixture")]:
        log_name = {"Fn::Sub": "/aws/lambda/${ResourcePrefix}-" + suffix}
        log_arn = {"Fn::Sub": "arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/lambda/${ResourcePrefix}-" + suffix + ":*"}
        resources[name + "LogGroup"] = {"Type": "AWS::Logs::LogGroup", "Properties": {"LogGroupName": log_name, "RetentionInDays": 7}}
        resources[name + "Role"] = {
            "Type": "AWS::IAM::Role", "Properties": {
                "AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Principal": {"Service": "lambda.amazonaws.com"}, "Action": "sts:AssumeRole"}]},
                "Policies": [{"PolicyName": "OwnFunctionLogs", "PolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": ["logs:CreateLogStream", "logs:PutLogEvents"], "Resource": log_arn}]}}],
            },
        }
        properties = {
            "FunctionName": {"Fn::Sub": "${ResourcePrefix}-" + suffix}, "Runtime": "python3.13",
            "Handler": "index.handler", "Architectures": ["arm64"], "MemorySize": 128,
            "Timeout": 10, "Role": {"Fn::GetAtt": [name + "Role", "Arn"]},
            "Description": "Fondeo review kit: pure validation or authored fixtures; no OCR/model calls.",
            "Code": {"ZipFile": (ROOT / source).read_text()},
        }
        resources[name + "Function"] = {"Type": "AWS::Lambda::Function", "DependsOn": name + "LogGroup", "Properties": properties}
        digest = hashlib.sha256(json.dumps(properties, sort_keys=True).encode()).hexdigest()[:12]
        version_name = name + "Version" + digest
        versions[name + "Arn"] = {"Ref": version_name}
        resources[version_name] = {
            "Type": "AWS::Lambda::Version", "DeletionPolicy": "Retain", "UpdateReplacePolicy": "Retain",
            "Properties": {"FunctionName": {"Ref": name + "Function"}, "Description": "Tested source/configuration " + digest},
        }
    resources["WorkflowRole"] = {
        "Type": "AWS::IAM::Role", "Properties": {
            "AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{
                "Effect": "Allow", "Principal": {"Service": "states.amazonaws.com"}, "Action": "sts:AssumeRole",
                "Condition": {
                    "StringEquals": {"aws:SourceAccount": {"Ref": "AWS::AccountId"}},
                    "ArnEquals": {"aws:SourceArn": {"Fn::Sub": "arn:${AWS::Partition}:states:${AWS::Region}:${AWS::AccountId}:stateMachine:${ResourcePrefix}-review"}},
                },
            }]},
            "Policies": [{"PolicyName": "InvokeOnlyReviewedVersions", "PolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": ["lambda:InvokeFunction"], "Resource": list(versions.values())}]}}],
        },
    }
    definition = json.dumps(json.loads((ROOT / "state-machine.asl.json").read_text()), separators=(",", ":"))
    resources["ReviewWorkflow"] = {
        "Type": "AWS::StepFunctions::StateMachine", "Properties": {
            "StateMachineName": {"Fn::Sub": "${ResourcePrefix}-review"}, "StateMachineType": "STANDARD",
            "RoleArn": {"Fn::GetAtt": ["WorkflowRole", "Arn"]},
            "DefinitionString": {"Fn::Sub": [definition, {**versions, "Partition": {"Ref": "AWS::Partition"}}]},
        },
    }
    return {
        "AWSTemplateFormatVersion": "2010-09-09",
        "Description": "Optional Fondeo review kit. Authored fixtures only; no public API, production authentication, Textract, Bedrock, or payment integration.",
        "Parameters": {"ResourcePrefix": {"Type": "String", "Default": "fondeo-demo", "MinLength": 3, "MaxLength": 36, "AllowedPattern": "[a-z][a-z0-9-]+", "Description": "Unique name for this review stack's functions and workflow."}},
        "Resources": resources,
        "Outputs": {
            "StateMachineArn": {"Value": {"Ref": "ReviewWorkflow"}},
            "Mode": {"Value": "Authored fixtures and explicit demo identity. Ready means ready for human review, never approved."},
        },
    }


def render():
    return json.dumps(template(), indent=2) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Check that the generated template matches its sources; write nothing.")
    args = parser.parse_args()
    output = ROOT / "template.json"
    expected = render()
    if args.check:
        if not output.exists() or output.read_text() != expected:
            raise SystemExit("Template is stale. Run python3 build_template.py.")
        print("Template exactly matches Python, runtime configuration and ASL sources.")
    else:
        output.write_text(expected)
        print(f"Wrote {output.name}: {len(expected.encode())} bytes. No AWS calls.")
