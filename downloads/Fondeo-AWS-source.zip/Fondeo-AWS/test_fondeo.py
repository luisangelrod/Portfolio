import copy
import json
from pathlib import Path
import unittest
import build_template
import extraction_adapter
import run_local
import validator

ROOT = Path(__file__).resolve().parent


def envelope(fixture="clean"):
    data = json.loads((ROOT / "example-input.json").read_text())
    data["document"]["fixture"] = fixture
    return data


def extracted(fixture="clean"):
    return extraction_adapter.handler(envelope(fixture))


def evaluate(data):
    return validator.handler({"operation": "validate", "payload": data})


class EvidenceTests(unittest.TestCase):
    def test_fixture_routes_are_executed_from_checked_in_asl(self):
        for fixture, terminal in [("clean", "ReadyForHumanReview"), ("conflict", "NeedsCorrection"), ("uncertain", "NeedsCorrection"), ("missing", "NeedsCorrection")]:
            with self.subTest(fixture=fixture):
                result = run_local.run(envelope(fixture))
                self.assertEqual(result["terminal"], terminal)
                self.assertIn("ExtractAuthoredFixture", result["visited"])
                self.assertFalse(result["result"]["approved"])
                self.assertTrue(result["result"]["requiresHumanReview"])

    def test_high_confidence_does_not_override_wrong_arithmetic_or_source(self):
        result = evaluate(extracted("conflict"))
        rules = {r["id"]: r["pass"] for r in result["rules"]}
        self.assertTrue(rules["confidence"])
        self.assertFalse(rules["arithmetic"])
        self.assertFalse(rules["source-total"])
        self.assertEqual(result["status"], "review")

    def test_missing_source_is_review_even_when_arithmetic_matches(self):
        result = evaluate(extracted("missing"))
        rules = {r["id"]: r["pass"] for r in result["rules"]}
        self.assertTrue(rules["arithmetic"])
        self.assertFalse(rules["source"])
        self.assertFalse(rules["source-total"])

    def test_tenant_mismatch_denies_before_extraction_and_withholds_details(self):
        data = envelope()
        data["document"]["tenantId"] = "norte-studio"
        result = run_local.run(data)
        self.assertEqual(result["terminal"], "Denied")
        self.assertNotIn("ExtractAuthoredFixture", result["visited"])
        self.assertEqual(set(result["result"]), {"status", "reason", "ruleVersion"})

    def test_adapter_also_denies_direct_mismatched_invocation(self):
        data = envelope()
        data["document"]["tenantId"] = "norte-studio"
        with self.assertRaises(ValueError):
            extraction_adapter.handler(data)

    def test_source_reference_cannot_cross_a_tenant_or_document(self):
        for field, value in [("tenantId", "norte-studio"), ("documentId", "another-document")]:
            data = extracted()
            data["extraction"]["sourceReference"][field] = value
            result = evaluate(data)
            self.assertEqual(result["status"], "denied")
            self.assertNotIn("amountCents", result)

    def test_wrong_operation_or_version_reference_requires_review(self):
        for field in ["documentVersion", "operationId", "blockId"]:
            data = extracted()
            data["extraction"]["sourceReference"][field] = "different"
            result = evaluate(data)
            self.assertEqual(result["status"], "review")
            self.assertFalse(next(r for r in result["rules"] if r["id"] == "source-reference")["pass"])

    def test_invalid_cents_are_rejected_including_python_booleans(self):
        for value in [True, False, -1, 0.5, "130000", 100000001, None]:
            data = extracted()
            data["extraction"]["amountCents"] = value
            self.assertEqual(evaluate(data)["status"], "invalid")

    def test_confidence_must_be_finite_bounded_and_not_boolean(self):
        for value in [True, -1, 101, float("nan"), float("inf"), "98"]:
            data = extracted()
            data["extraction"]["confidence"] = value
            self.assertEqual(evaluate(data)["status"], "invalid")

    def test_confidence_threshold_is_inclusive(self):
        for confidence, status in [(79.99, "review"), (80, "ready")]:
            data = extracted()
            data["extraction"]["confidence"] = confidence
            self.assertEqual(evaluate(data)["status"], status)

    def test_model_verification_or_approval_flags_are_not_trusted(self):
        for field in ["verified", "approved", "instruction"]:
            data = extracted("uncertain")
            data["extraction"][field] = True
            self.assertEqual(evaluate(data)["status"], "invalid")

    def test_empty_duplicate_or_unbounded_line_items_are_invalid(self):
        for lines in [[], [{"id": "a", "amountCents": 1}] * 2, [{"id": str(i), "amountCents": 1} for i in range(51)]]:
            data = extracted()
            data["extraction"]["lineItems"] = lines
            self.assertEqual(evaluate(data)["status"], "invalid")

    def test_receipt_is_deterministic_and_changes_with_evidence(self):
        data = extracted()
        original = copy.deepcopy(data)
        first = evaluate(data)
        self.assertEqual(first, evaluate(data))
        self.assertEqual(data, original)
        data["extraction"]["confidence"] = 90
        self.assertNotEqual(first["inputSha256"], evaluate(data)["inputSha256"])

    def test_unreviewed_adapter_provenance_is_rejected(self):
        data = extracted()
        data["provenance"]["adapter"] = "bedrock-real"
        self.assertEqual(evaluate(data)["status"], "invalid")

    def test_invalid_envelopes_follow_fail_state(self):
        for value in [None, {}, [], {**envelope(), "unreviewed": True}]:
            self.assertEqual(run_local.run(value)["terminal"], "InvalidInput")

    def test_unexpected_task_error_routes_to_explicit_failure(self):
        def broken(*_args):
            raise RuntimeError("Adapter unavailable")
        result = run_local.run(envelope(), {"${ValidatorArn}": validator.handler, "${ExtractorArn}": broken})
        self.assertEqual(result["terminal"], "ExecutionFailed")
        self.assertEqual(result["result"], {"error": "DocumentProcessingFailed"})


class ArtifactTests(unittest.TestCase):
    def test_cloudformation_is_exactly_generated_from_reviewed_sources(self):
        self.assertEqual((ROOT / "template.json").read_text(), build_template.render())
        self.assertLess(len(build_template.render().encode()), 51200)

    def test_inline_lambda_modules_compile_and_use_index_handler(self):
        resources = build_template.template()["Resources"]
        for key in ["ValidatorFunction", "ExtractorFunction"]:
            properties = resources[key]["Properties"]
            self.assertEqual(properties["Handler"], "index.handler")
            self.assertEqual(properties["Runtime"], "python3.13")
            compile(properties["Code"]["ZipFile"], "index.py", "exec")

    def test_workflow_invokes_only_versioned_functions_and_has_no_extraction_permissions(self):
        resources = build_template.template()["Resources"]
        policy = resources["WorkflowRole"]["Properties"]["Policies"][0]["PolicyDocument"]["Statement"][0]
        self.assertEqual(policy["Action"], ["lambda:InvokeFunction"])
        for ref in policy["Resource"]:
            self.assertEqual(resources[ref["Ref"]]["Type"], "AWS::Lambda::Version")
        for resource in resources.values():
            if resource["Type"] == "AWS::IAM::Role":
                for policy in resource["Properties"].get("Policies", []):
                    for statement in policy["PolicyDocument"]["Statement"]:
                        self.assertFalse(any(action.startswith(("textract:", "bedrock:", "s3:", "dynamodb:")) for action in statement["Action"]))

    def test_state_references_exist_and_every_task_is_bounded(self):
        definition = json.loads((ROOT / "state-machine.asl.json").read_text())
        states = definition["States"]
        for state in states.values():
            targets = [state[k] for k in ["Next", "Default"] if k in state]
            targets += [choice["Next"] for choice in state.get("Choices", [])]
            targets += [catch["Next"] for catch in state.get("Catch", [])]
            self.assertTrue(all(target in states for target in targets))
            if state["Type"] == "Task":
                self.assertLessEqual(state["TimeoutSeconds"], 15)
                self.assertEqual(state["OutputPath"], "$.Payload")
                self.assertLessEqual(state["Retry"][0]["MaxAttempts"], 2)
                self.assertNotIn("States.ALL", state["Retry"][0]["ErrorEquals"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
