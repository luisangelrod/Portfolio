"""Authored extraction fixtures. This module performs no OCR or model inference.

Replace this explicit adapter boundary only after implementing authenticated S3
document resolution, Textract pagination/job completion, source references,
optional Bedrock normalization, and a separately reviewed provenance contract.
"""
from copy import deepcopy

FIXTURES = {
    "clean": (130000, 98, True),
    "conflict": (180000, 97, True),
    "uncertain": (130000, 62, True),
    "missing": (130000, 94, False),
}


def handler(envelope, _context=None):
    # The state machine runs the validator gate before this adapter.
    # Defensive direct-invocation checks still deny mismatched tenant context.
    if (not isinstance(envelope, dict) or not isinstance(envelope.get("document"), dict)
            or not isinstance(envelope.get("context"), dict)):
        raise ValueError("Expected a gated envelope.")
    document, context = envelope["document"], envelope["context"]
    if (not context.get("tenantId") or context["tenantId"] != document.get("tenantId")
            or context.get("identityMode") != "explicit-demo-identity"):
        raise ValueError("Document is outside the supplied demo workspace.")
    if document.get("fixture") not in FIXTURES:
        raise ValueError("Unsupported authored fixture.")
    amount, confidence, present = FIXTURES[document["fixture"]]
    reference = {"tenantId": document["tenantId"], "documentId": document["id"],
                 "documentVersion": "fixture-v1", "operationId": "authored-extraction-v1", "blockId": "T-01"}
    return {
        "schemaVersion": "fondeo-extraction/1", "envelope": deepcopy(envelope),
        "source": {"present": present, "totalCents": 130000 if present else None, "reference": deepcopy(reference)},
        "extraction": {"amountCents": amount, "confidence": confidence,
                       "lineItems": [{"id": "interface-design", "amountCents": 90000},
                                     {"id": "implementation-review", "amountCents": 40000}],
                       "sourceReference": deepcopy(reference)},
        "provenance": {"adapter": "authored-fixture/1", "evidence": "synthetic-not-recorded"},
    }
