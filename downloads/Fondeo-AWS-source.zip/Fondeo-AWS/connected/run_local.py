"""Execute the checked-in ASL Task/Choice/Succeed/Fail subset with injected synthetic AWS clients."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import fixtures
import pipeline

ROOT = Path(__file__).resolve().parent


def select(value, path):
    if path == "$":
        return value
    if not path.startswith("$."):
        raise ValueError("Unsupported JSONPath.")
    for part in path[2:].split("."):
        value = value[part]
    return value


def parameters(spec, value):
    return {key[:-2] if key.endswith(".$") else key:
            select(value, item) if key.endswith(".$") else parameters(item, value) if isinstance(item, dict) else item
            for key, item in spec.items()}


def run(case="conflict", envelope=None, clients=None):
    definition = json.loads((ROOT / "state-machine.asl.json").read_text())
    clients = clients or {"extract": fixtures.FakeTextract(case), "propose": fixtures.FakeBedrock(case)}
    current, value, visits, events = definition["StartAt"], deepcopy(envelope or fixtures.ENVELOPE), [], []
    for _ in range(30):
        state = definition["States"][current]
        visits.append(current)
        if state["Type"] == "Task":
            args = parameters(state["Parameters"], value)
            try:
                result = pipeline.invoke(args["Payload"], deepcopy(fixtures.CONFIG), clients)
                value = select({"Payload": result}, state["OutputPath"])
                events.append({"state": current, "outcome": "completed"})
                current = state["Next"]
            except Exception as exc:
                events.append({"state": current, "outcome": "caught", "errorType": type(exc).__name__, "message": str(exc)})
                current = state["Catch"][0]["Next"]
        elif state["Type"] == "Choice":
            current = state["Default"]
            for choice in state["Choices"]:
                if select(value, choice["Variable"]) == choice["StringEquals"]:
                    current = choice["Next"]
                    break
        elif state["Type"] in ("Succeed", "Fail"):
            return {"engine": "connected-local-asl-subset/1", "evidenceMode": "authored-api-fixtures", "cloudExecution": False,
                    "terminal": current, "visited": visits, "events": events,
                    "result": value if state["Type"] == "Succeed" else {"error": state["Error"]},
                    "limits": "Actual Python parsing and checked-in ASL wiring, with synthetic injected SDK clients. No OCR, model inference, Lambda runtime, IAM, AWS retry timing or cloud execution was tested."}
        else:
            raise ValueError("Unsupported local state.")
    raise ValueError("Traversal limit reached.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", default="conflict", choices=("clean", "conflict", "uncertain", "missing"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    rendered = json.dumps(run(args.case), indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(rendered, end="")
