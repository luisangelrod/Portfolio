"""Generate the reviewable ASL/CloudFormation and fixed fictional one-page PDF. Never contacts AWS."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def state_machine():
    states = {}
    operations = [("ValidateInputAndScope", "gate", "$", "ScopeDecision"),
                  ("ExtractWithTextract", "extract", "$.envelope", "ExplainWithBedrock"),
                  ("ExplainWithBedrock", "propose", "$", "ValidateEvidence"),
                  ("ValidateEvidence", "validate", "$", "ReviewDecision"),
                  ("ValidateWithoutProposal", "validate", "$", "ReviewDecision")]
    for name, operation, path, next_state in operations:
        payload = {"operation": operation, "payload.$": path}
        if name == "ValidateWithoutProposal":
            payload["proposalUnavailable"] = True
        states[name] = {"Type": "Task", "Resource": "arn:${Partition}:states:::lambda:invoke",
                        "Parameters": {"FunctionName": "${PipelineArn}", "Payload": payload}, "OutputPath": "$.Payload",
                        "TimeoutSeconds": 40, "Next": next_state,
                        "Retry": [{"ErrorEquals": ["Lambda.ServiceException", "Lambda.AWSLambdaException", "Lambda.SdkClientException", "Lambda.TooManyRequestsException"],
                                   "MaxAttempts": 1, "IntervalSeconds": 2, "BackoffRate": 2, "JitterStrategy": "FULL"}],
                        "Catch": [{"ErrorEquals": ["States.ALL"], "ResultPath": None, "Next": "ValidateWithoutProposal" if operation == "propose" else "ProcessingFailed"}]}
    states["ScopeDecision"] = {"Type": "Choice", "Choices": [
        {"Variable": "$.status", "StringEquals": "accepted", "Next": "ExtractWithTextract"},
        {"Variable": "$.status", "StringEquals": "denied", "Next": "Denied"}], "Default": "InvalidInput"}
    states["ReviewDecision"] = {"Type": "Choice", "Choices": [
        {"Variable": "$.status", "StringEquals": "ready", "Next": "ReadyForHumanReview"},
        {"Variable": "$.status", "StringEquals": "review", "Next": "NeedsCorrection"},
        {"Variable": "$.status", "StringEquals": "denied", "Next": "Denied"}], "Default": "InvalidInput"}
    for name in ("ReadyForHumanReview", "NeedsCorrection", "Denied"):
        states[name] = {"Type": "Succeed"}
    states["InvalidInput"] = {"Type": "Fail", "Error": "InvalidDocumentInput"}
    states["ProcessingFailed"] = {"Type": "Fail", "Error": "DocumentProcessingFailed"}
    return {"Comment": "Source-only connected path; disabled by default. Local receipts use authored SDK responses.",
            "QueryLanguage": "JSONPath", "StartAt": "ValidateInputAndScope", "TimeoutSeconds": 180, "States": states}


def template():
    code = (ROOT / "pipeline.py").read_text()
    environment = {"ENABLE_AWS_CALLS": {"Ref": "EnableAwsCalls"}, "SOURCE_BUCKET": {"Ref": "SourceBucket"},
                   "SOURCE_VERSION": {"Ref": "SourceVersion"}, "MODEL_ARN": {"Ref": "ModelArn"}}
    source_arn = {"Fn::Sub": "arn:${AWS::Partition}:s3:::${SourceBucket}/fondeo-demo/fictitious-invoice-v1.pdf"}
    properties = {"FunctionName": {"Fn::Sub": "${ResourcePrefix}-pipeline"}, "Runtime": "python3.13", "Handler": "index.handler",
                  "Architectures": ["arm64"], "MemorySize": 256, "Timeout": 35, "ReservedConcurrentExecutions": 1,
                  "Role": {"Fn::GetAtt": ["PipelineRole", "Arn"]}, "Environment": {"Variables": environment}, "Code": {"ZipFile": code}}
    digest = hashlib.sha256(json.dumps(properties, sort_keys=True).encode()).hexdigest()[:12]
    version = "PipelineVersion" + digest
    resource_arn = {"Fn::Sub": "arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/lambda/${ResourcePrefix}-pipeline:*"}
    resources = {
        "PipelineLog": {"Type": "AWS::Logs::LogGroup", "Properties": {"LogGroupName": {"Fn::Sub": "/aws/lambda/${ResourcePrefix}-pipeline"}, "RetentionInDays": 7}},
        "PipelineRole": {"Type": "AWS::IAM::Role", "Properties": {
            "AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Principal": {"Service": "lambda.amazonaws.com"}, "Action": "sts:AssumeRole"}]},
            "Policies": [{"PolicyName": "ReviewedSourceAndModelOnly", "PolicyDocument": {"Version": "2012-10-17", "Statement": [
                {"Effect": "Allow", "Action": ["logs:CreateLogStream", "logs:PutLogEvents"], "Resource": resource_arn},
                {"Fn::If": ["CallsEnabled", {"Effect": "Allow", "Action": ["s3:GetObjectVersion"], "Resource": source_arn,
                    "Condition": {"StringEquals": {"s3:VersionId": {"Ref": "SourceVersion"}}}}, {"Ref": "AWS::NoValue"}]},
                {"Fn::If": ["CallsEnabled", {"Effect": "Allow", "Action": ["textract:AnalyzeDocument"], "Resource": "*"}, {"Ref": "AWS::NoValue"}]},
                {"Fn::If": ["CallsEnabled", {"Effect": "Allow", "Action": ["bedrock:InvokeModel"], "Resource": {"Ref": "ModelArn"}}, {"Ref": "AWS::NoValue"}]},
            ]}}]}},
        "PipelineFunction": {"Type": "AWS::Lambda::Function", "DependsOn": "PipelineLog", "Properties": properties},
        version: {"Type": "AWS::Lambda::Version", "DeletionPolicy": "Retain", "UpdateReplacePolicy": "Retain", "Properties": {
            "FunctionName": {"Ref": "PipelineFunction"}, "Description": {"Fn::Sub": digest + "|${EnableAwsCalls}|${SourceBucket}|${SourceVersion}|${ModelArn}"}}},
        "WorkflowRole": {"Type": "AWS::IAM::Role", "Properties": {
            "AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Principal": {"Service": "states.amazonaws.com"}, "Action": "sts:AssumeRole",
                "Condition": {"StringEquals": {"aws:SourceAccount": {"Ref": "AWS::AccountId"}}, "ArnEquals": {"aws:SourceArn": {"Fn::Sub": "arn:${AWS::Partition}:states:${AWS::Region}:${AWS::AccountId}:stateMachine:${ResourcePrefix}-review"}}}}]},
            "Policies": [{"PolicyName": "ReviewedVersionOnly", "PolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": ["lambda:InvokeFunction"], "Resource": {"Ref": version}}]}}]}},
        "Workflow": {"Type": "AWS::StepFunctions::StateMachine", "Properties": {"StateMachineName": {"Fn::Sub": "${ResourcePrefix}-review"}, "StateMachineType": "STANDARD",
            "RoleArn": {"Fn::GetAtt": ["WorkflowRole", "Arn"]}, "DefinitionString": {"Fn::Sub": [json.dumps(state_machine(), separators=(",", ":")), {"PipelineArn": {"Ref": version}, "Partition": {"Ref": "AWS::Partition"}}]}}},
    }
    return {"AWSTemplateFormatVersion": "2010-09-09", "Description": "Fondeo connected source review. Disabled SDK calls and no public endpoint. Not deployed or AWS validated.",
            "Parameters": {
                "ResourcePrefix": {"Type": "String", "Default": "fondeo-connected-review", "AllowedPattern": "[a-z][a-z0-9-]{2,35}"},
                "EnableAwsCalls": {"Type": "String", "Default": "false", "AllowedValues": ["false", "true"]},
                "SourceBucket": {"Type": "String", "MaxLength": 63, "Default": "operator-must-configure-reviewed-bucket", "Description": "Existing bucket containing only the separately reviewed fictional PDF at the fixed key."},
                "SourceVersion": {"Type": "String", "MaxLength": 40, "Default": "operator-must-configure-immutable-version", "Description": "Exact version ID of the reviewed PDF, at most 40 characters; null/unversioned objects are rejected."},
                "ModelArn": {"Type": "String", "MaxLength": 110, "Default": "arn:aws:bedrock:us-east-1::foundation-model/reviewed-model-placeholder", "Description": "Operator-selected regional model ARN supporting Converse and these inference controls; placeholder is not a real model."}},
            "Conditions": {"CallsEnabled": {"Fn::Equals": [{"Ref": "EnableAwsCalls"}, "true"]}}, "Resources": resources,
            "Outputs": {"StateMachineArn": {"Value": {"Ref": "Workflow"}}, "Mode": {"Value": "Source review only. Enabling creates metered service capability; no authenticated starter or approval persistence."}}}


def pdf_bytes():
    lines = [(22, "FICTIONAL DEMONSTRATION"), (15, "Fondeo - Invoice 001"), (12, "This document is a synthetic test input. It is not payable."),
             (14, "Interface design                                      $900.00"), (14, "Implementation review                         $400.00"),
             (18, "Total amount due                                  $1,300.00")]
    content = "BT\n"
    for index, (size, line) in enumerate(lines):
        escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        content += f"/F1 {size} Tf\n1 0 0 1 50 {740 - index * 70} Tm\n({escaped}) Tj\n"
    content += "ET\n"
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
               b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
               b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
               f"<< /Length {len(content.encode())} >>\nstream\n{content}endstream".encode()]
    output, offsets = b"%PDF-1.4\n", [0]
    for index, obj in enumerate(objects, 1):
        offsets.append(len(output))
        output += f"{index} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(output)
    output += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    output += b"".join(f"{offset:010d} 00000 n \n".encode() for offset in offsets[1:])
    return output + f"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()


def artifacts():
    pdf = pdf_bytes()
    return {"state-machine.asl.json": (json.dumps(state_machine(), indent=2) + "\n").encode(),
            "template.json": (json.dumps(template(), indent=2) + "\n").encode(), "fictitious-invoice-v1.pdf": pdf,
            "source-manifest.json": (json.dumps({"documentId": "fondeo-fictitious-invoice-v1", "fixedS3Key": "fondeo-demo/fictitious-invoice-v1.pdf",
                "sha256": hashlib.sha256(pdf).hexdigest(), "bytes": len(pdf), "authoredGroundTruthCents": 130000,
                "evidence": "Authored ground truth for this synthetic PDF only. Not copied from OCR and not used as production validation."}, indent=2) + "\n").encode()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    for name, value in artifacts().items():
        path = ROOT / name
        if args.check:
            if not path.exists() or path.read_bytes() != value:
                raise SystemExit(f"Stale generated artifact: {name}")
        else:
            path.write_bytes(value)
    print("Artifacts exactly match sources." if args.check else "Wrote local review artifacts. No AWS calls.")
