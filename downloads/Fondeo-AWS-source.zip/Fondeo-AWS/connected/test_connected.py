from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import build_artifacts
import fixtures
import pipeline
import run_local

ROOT = Path(__file__).resolve().parent


def extracted(case="conflict"):
    return pipeline.invoke({"operation": "extract", "payload": deepcopy(fixtures.ENVELOPE)}, deepcopy(fixtures.CONFIG), {"extract": fixtures.FakeTextract(case)})


class AdapterTests(unittest.TestCase):
    def test_closed_switch_never_imports_sdk_or_resolves_credentials(self):
        real_import = __import__
        attempted = []
        def guarded_import(name, *args, **kwargs):
            if name in ("boto3", "botocore.config"):
                attempted.append(name)
                raise AssertionError("SDK import attempted while closed.")
            return real_import(name, *args, **kwargs)
        config = deepcopy(fixtures.CONFIG)
        config["evidenceMode"] = "aws-service-responses"
        with patch("builtins.__import__", side_effect=guarded_import):
            with self.assertRaises(pipeline.CloudDisabled):
                pipeline.invoke({"operation": "extract", "payload": fixtures.ENVELOPE}, config)
        self.assertEqual(attempted, [])

    def test_runtime_environment_gate_defaults_closed(self):
        with patch.dict("os.environ", {}, clear=True):
            self.assertFalse(pipeline.config_from_environment()["enabled"])

    def test_scope_denial_happens_before_either_service(self):
        value = deepcopy(fixtures.ENVELOPE)
        value["context"]["tenantId"] = "another-tenant"
        clients = {"extract": fixtures.FakeTextract(), "propose": fixtures.FakeBedrock()}
        result = run_local.run(envelope=value, clients=clients)
        self.assertEqual(result["terminal"], "Denied")
        self.assertEqual(clients["extract"].calls, [])
        self.assertEqual(clients["propose"].calls, [])
        self.assertEqual(set(result["result"]), {"status", "reason"})

    def test_input_cannot_choose_bucket_key_version_model_or_another_document(self):
        for key in ("bucket", "key", "version", "modelArn"):
            value = deepcopy(fixtures.ENVELOPE)
            value[key] = "attacker-controlled"
            self.assertEqual(run_local.run(envelope=value)["terminal"], "InvalidInput")
        value = deepcopy(fixtures.ENVELOPE)
        value["documentId"] = "another-invoice"
        self.assertEqual(run_local.run(envelope=value)["terminal"], "InvalidInput")

    def test_sdk_request_is_fixed_version_and_response_keeps_references(self):
        client = fixtures.FakeTextract()
        result = pipeline.invoke({"operation": "extract", "payload": fixtures.ENVELOPE}, fixtures.CONFIG, {"extract": client})
        self.assertEqual(len(client.calls), 1)
        self.assertEqual(result["source"]["version"], fixtures.CONFIG["version"])
        self.assertEqual(result["ocr"]["fields"]["total"]["blockId"], "answer-total")
        self.assertEqual(result["ocr"]["fields"]["total"]["queryId"], "query-total")
        self.assertEqual(result["ocr"]["fields"]["total"]["page"], 1)
        self.assertEqual(result["ocr"]["fields"]["total"]["bounds"]["Left"], .72)
        self.assertFalse(result["cloudExecution"])

    def test_missing_answer_is_retained_as_missing_not_filled_with_fixture_truth(self):
        payload = extracted("missing")
        self.assertNotIn("total", payload["ocr"]["fields"])
        result = pipeline.validate(payload, fixtures.CONFIG)
        self.assertEqual(result["status"], "review")
        self.assertIsNone(result["amountCents"])

    def test_duplicate_ids_aliases_reused_answers_and_wrong_page_are_rejected(self):
        mutations = [
            lambda v: v["Blocks"].append(deepcopy(v["Blocks"][0])),
            lambda v: v["Blocks"][2]["Query"].update(Alias="total"),
            lambda v: v["Blocks"][2]["Relationships"][0].update(Ids=["answer-total"]),
            lambda v: v["Blocks"][1].update(Page=2),
            lambda v: v["Blocks"][0]["Relationships"][0].update(Ids=["missing-id"]),
        ]
        for mutation in mutations:
            response = fixtures.textract_response()
            mutation(response)
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.parse_textract(response)

    def test_invalid_geometry_confidence_and_ambiguous_currency_are_rejected(self):
        for bad in ("1.300,00", "1300", "$1,30.00", "-1.00", "NaN", "$1,000,000.01"):
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.cents(bad)
        for confidence in (True, float("nan"), float("inf"), -1, 101):
            response = fixtures.textract_response()
            response["Blocks"][1]["Confidence"] = confidence
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.parse_textract(response)
        response = fixtures.textract_response()
        response["Blocks"][1]["Geometry"]["BoundingBox"]["Width"] = .8
        with self.assertRaises(pipeline.InvalidInput):
            pipeline.parse_textract(response)

    def test_response_limits_and_single_page_contract(self):
        for mutation in (lambda v: v.update(unbounded="x" * 262145), lambda v: v["DocumentMetadata"].update(Pages=2)):
            response = fixtures.textract_response()
            mutation(response)
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.parse_textract(response)

    def test_converse_is_bounded_and_sends_only_extracted_evidence(self):
        client = fixtures.FakeBedrock()
        payload = extracted()
        original = deepcopy(payload)
        result = pipeline.propose(payload, fixtures.CONFIG, client)
        self.assertEqual(payload, original)
        self.assertEqual(client.calls[0]["inferenceConfig"]["maxTokens"], 240)
        sent = json.loads(client.calls[0]["messages"][0]["content"][0]["text"])
        self.assertEqual(set(sent), {"fields", "promptVersion"})
        self.assertNotIn("context", sent)
        self.assertEqual(result["proposal"]["modelArn"], fixtures.CONFIG["modelArn"])
        self.assertEqual(json.loads(result["proposal"]["rawText"]), result["proposal"]["parsed"])

    def test_model_cannot_set_amount_approval_verified_tenant_or_external_citations(self):
        payload = extracted()
        base = json.loads(fixtures.bedrock_response()["output"]["message"]["content"][0]["text"])
        for key in ("amountCents", "approved", "verified", "tenantId", "instructions"):
            proposal = {**base, key: True}
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.check_proposal(proposal, payload["ocr"]["fields"])
        for citations in (["another-run-block"], [], ["answer-total", "answer-total"]):
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.check_proposal({**base, "evidenceBlockIds": citations}, payload["ocr"]["fields"])

    def test_model_tool_use_truncation_extra_text_and_invalid_json_are_rejected(self):
        mutations = [lambda v: v.update(stopReason="max_tokens"), lambda v: v.update(stopReason="tool_use"),
                     lambda v: v["output"]["message"]["content"].append({"text": "extra"}),
                     lambda v: v["output"]["message"]["content"][0].update(text="Not JSON"),
                     lambda v: v["output"]["message"]["content"][0].update(text="x" * 4097)]
        for mutation in mutations:
            response = fixtures.bedrock_response()
            mutation(response)
            with self.assertRaises(pipeline.InvalidInput):
                pipeline.propose(extracted(), fixtures.CONFIG, fixtures.FakeBedrock(response=response))

    def test_injected_clients_cannot_claim_live_evidence(self):
        config = deepcopy(fixtures.CONFIG)
        config["evidenceMode"] = "aws-service-responses"
        with self.assertRaises(pipeline.InvalidInput):
            pipeline.invoke({"operation": "extract", "payload": fixtures.ENVELOPE}, config, {"extract": fixtures.FakeTextract()})


class ValidationTests(unittest.TestCase):
    def test_all_recorded_paths_execute_checked_in_asl(self):
        for case, terminal in (("clean", "ReadyForHumanReview"), ("conflict", "NeedsCorrection"), ("uncertain", "NeedsCorrection"), ("missing", "NeedsCorrection")):
            result = run_local.run(case)
            self.assertEqual(result["terminal"], terminal)
            self.assertIn("ExtractWithTextract", result["visited"])
            self.assertIn("ExplainWithBedrock", result["visited"])
            self.assertFalse(result["result"]["approved"])
            self.assertTrue(result["result"]["requiresHumanReview"])
            self.assertFalse(result["cloudExecution"])

    def test_confident_error_and_arithmetic_are_independent_of_model_explanation(self):
        payload = extracted()
        result = pipeline.validate(payload, fixtures.CONFIG)
        rules = {rule["id"]: rule["pass"] for rule in result["rules"]}
        self.assertTrue(rules["recognition-confidence"])
        self.assertFalse(rules["line-item-arithmetic"])
        self.assertEqual(result["lineTotalCents"], 130000)
        self.assertEqual(result["amountCents"], 180000)

    def test_same_wrong_ocr_total_and_lines_are_not_claimed_ground_truth(self):
        payload = extracted("clean")
        payload["ocr"]["fields"]["total"].update(text="$1,800.00", amountCents=180000)
        payload["ocr"]["fields"]["line1"].update(text="$1,400.00", amountCents=140000)
        result = pipeline.validate(payload, fixtures.CONFIG)
        self.assertEqual(result["status"], "ready")
        self.assertFalse(result["approved"])
        self.assertIn("does not prove correct extraction", result["limits"])

    def test_tampered_values_flags_references_and_stale_version_are_rejected(self):
        mutations = [lambda v: v["source"].update(version="old-version"), lambda v: v["source"].update(bucket="another-bucket"),
                     lambda v: v["ocr"]["fields"]["total"].update(amountCents=True),
                     lambda v: v["ocr"]["fields"]["total"].update(amountCents=130000),
                     lambda v: v["ocr"]["fields"]["line1"].update(blockId="answer-total"),
                     lambda v: v.update(approved=True), lambda v: v.update(cloudExecution=True)]
        for mutation in mutations:
            payload = extracted()
            mutation(payload)
            result = pipeline.invoke({"operation": "validate", "payload": payload}, fixtures.CONFIG)
            self.assertEqual(result["status"], "invalid")

    def test_fingerprint_is_stable_and_sensitive_to_source_evidence(self):
        payload = extracted()
        before = deepcopy(payload)
        original = pipeline.validate(payload, fixtures.CONFIG)
        self.assertEqual(original, pipeline.validate(payload, fixtures.CONFIG))
        self.assertEqual(payload, before)
        payload["ocr"]["fields"]["total"]["confidence"] = 90
        self.assertNotEqual(original["inputSha256"], pipeline.validate(payload, fixtures.CONFIG)["inputSha256"])

    def test_model_outage_keeps_deterministic_validation_available(self):
        clients = {"extract": fixtures.FakeTextract("clean"), "propose": fixtures.FakeBedrock(unavailable=True)}
        result = run_local.run("clean", clients=clients)
        self.assertIn("ValidateWithoutProposal", result["visited"])
        self.assertEqual(result["terminal"], "ReadyForHumanReview")
        self.assertTrue(result["result"]["proposalUnavailable"])
        self.assertIsNone(result["result"]["proposal"])
        self.assertFalse(result["result"]["approved"])

    def test_invalid_model_output_is_rejected_and_never_changes_ocr(self):
        response = fixtures.bedrock_response()
        response["output"]["message"]["content"][0]["text"] = '{"approved": true}'
        result = run_local.run(clients={"extract": fixtures.FakeTextract(), "propose": fixtures.FakeBedrock(response=response)})
        self.assertEqual(result["terminal"], "NeedsCorrection")
        self.assertTrue(result["result"]["proposalUnavailable"])
        self.assertEqual(result["result"]["amountCents"], 180000)

    def test_extraction_failure_is_not_presented_as_a_review_result(self):
        class Broken:
            def analyze_document(self, **_kwargs):
                raise RuntimeError("Authored unavailable source")
        result = run_local.run(clients={"extract": Broken(), "propose": fixtures.FakeBedrock()})
        self.assertEqual(result["terminal"], "ProcessingFailed")
        self.assertNotIn("amountCents", result["result"])


class ArtifactTests(unittest.TestCase):
    def test_generated_sources_are_exact_and_inline_template_fits(self):
        for name, expected in build_artifacts.artifacts().items():
            self.assertEqual((ROOT / name).read_bytes(), expected)
        self.assertLess(len((ROOT / "template.json").read_bytes()), 51200)

    def test_embedded_runtime_compiles_and_gate_is_disabled_by_default(self):
        template = build_artifacts.template()
        self.assertEqual(template["Parameters"]["EnableAwsCalls"]["Default"], "false")
        properties = template["Resources"]["PipelineFunction"]["Properties"]
        self.assertEqual(properties["Runtime"], "python3.13")
        self.assertEqual(properties["Handler"], "index.handler")
        compile(properties["Code"]["ZipFile"], "index.py", "exec")

    def test_call_permissions_are_conditional_and_scope_object_version_and_model(self):
        template = build_artifacts.template()
        statements = template["Resources"]["PipelineRole"]["Properties"]["Policies"][0]["PolicyDocument"]["Statement"]
        self.assertEqual(len(statements), 4)
        for conditional in statements[1:]:
            self.assertEqual(conditional["Fn::If"][0], "CallsEnabled")
            self.assertEqual(conditional["Fn::If"][2], {"Ref": "AWS::NoValue"})
        s3 = statements[1]["Fn::If"][1]
        self.assertEqual(s3["Action"], ["s3:GetObjectVersion"])
        self.assertIn("fondeo-demo/fictitious-invoice-v1.pdf", s3["Resource"]["Fn::Sub"])
        self.assertEqual(s3["Condition"]["StringEquals"]["s3:VersionId"], {"Ref": "SourceVersion"})
        self.assertEqual(statements[3]["Fn::If"][1]["Resource"], {"Ref": "ModelArn"})

    def test_immutable_version_changes_when_runtime_parameter_values_change(self):
        template = build_artifacts.template()
        version = next(v for v in template["Resources"].values() if v["Type"] == "AWS::Lambda::Version")
        description = version["Properties"]["Description"]["Fn::Sub"]
        for key in ("EnableAwsCalls", "SourceBucket", "SourceVersion", "ModelArn"):
            self.assertIn("${" + key + "}", description)
        maximum = len(description)
        for key, size in (("EnableAwsCalls", 5), ("SourceBucket", 63), ("SourceVersion", 40), ("ModelArn", 110)):
            maximum += size - len("${" + key + "}")
        self.assertLessEqual(maximum, 256)
        policy = template["Resources"]["WorkflowRole"]["Properties"]["Policies"][0]["PolicyDocument"]["Statement"][0]
        self.assertEqual(template["Resources"][policy["Resource"]["Ref"]]["Type"], "AWS::Lambda::Version")

    def test_asl_targets_limits_and_model_fallback_are_explicit(self):
        states = build_artifacts.state_machine()["States"]
        for state in states.values():
            targets = [state[key] for key in ("Next", "Default") if key in state]
            targets.extend(choice["Next"] for choice in state.get("Choices", []))
            targets.extend(catch["Next"] for catch in state.get("Catch", []))
            self.assertTrue(all(target in states for target in targets))
            if state["Type"] == "Task":
                self.assertEqual(state["TimeoutSeconds"], 40)
                self.assertEqual(state["Retry"][0]["MaxAttempts"], 1)
                self.assertNotIn("States.ALL", state["Retry"][0]["ErrorEquals"])
        self.assertEqual(states["ExplainWithBedrock"]["Catch"][0]["Next"], "ValidateWithoutProposal")

    def test_synthetic_pdf_has_independent_manifest_and_stable_bytes(self):
        pdf = (ROOT / "fictitious-invoice-v1.pdf").read_bytes()
        manifest = json.loads((ROOT / "source-manifest.json").read_text())
        self.assertEqual(manifest["sha256"], hashlib.sha256(pdf).hexdigest())
        self.assertEqual(manifest["authoredGroundTruthCents"], 130000)
        self.assertIn(b"FICTIONAL DEMONSTRATION", pdf)
        self.assertIn(b"1,300.00", pdf)
        self.assertNotIn("authoredGroundTruthCents", (ROOT / "pipeline.py").read_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
