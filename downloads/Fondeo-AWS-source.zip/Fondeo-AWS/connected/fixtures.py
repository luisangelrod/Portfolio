"""Authored API-shaped fixtures. None is a captured AWS/model response."""
from copy import deepcopy
import json
import pipeline

CONFIG = {"enabled": False, "bucket": "fondeo-review-fixture", "key": pipeline.KEY,
          "version": "authored-version-not-uploaded", "modelArn": "arn:aws:bedrock:us-east-1::foundation-model/reviewed-model-placeholder",
          "tenantId": "fondeo-demo", "evidenceMode": "authored-api-fixtures"}
ENVELOPE = {"schemaVersion": pipeline.SCHEMA, "requestId": "local-review-001",
            "context": {"tenantId": "fondeo-demo", "actorId": "reviewer", "identityMode": "explicit-demo-identity"},
            "documentId": pipeline.DOCUMENT}


def textract_response(case="conflict"):
    values = {"total": "$1,800.00" if case == "conflict" else "$1,300.00", "line1": "$900.00", "line2": "$400.00"}
    blocks = []
    for index, alias in enumerate(pipeline.ALIASES):
        query = {"Id": "query-" + alias, "BlockType": "QUERY", "Page": 1,
                 "Query": deepcopy(pipeline.QUERIES[index]), "Relationships": [{"Type": "ANSWER", "Ids": ["answer-" + alias]}]}
        answer = {"Id": "answer-" + alias, "BlockType": "QUERY_RESULT", "Page": 1, "Text": values[alias],
                  "Confidence": 62 if case == "uncertain" and alias == "total" else 97,
                  "Geometry": {"BoundingBox": {"Left": 0.72, "Top": 0.35 + index * 0.1, "Width": 0.19, "Height": 0.03}}}
        if case == "missing" and alias == "total":
            query["Relationships"] = []
            blocks.append(query)
        else:
            blocks.extend([query, answer])
    return {"DocumentMetadata": {"Pages": 1}, "Blocks": blocks, "AnalyzeDocumentModelVersion": "authored-model-version",
            "ResponseMetadata": {"RequestId": "authored-textract-request"}}


def bedrock_response(case="conflict"):
    selected = "none" if case == "missing" else "total"
    value = {"field": selected, "evidenceBlockIds": [] if selected == "none" else ["answer-total", "answer-line1", "answer-line2"],
             "reason": "Authored example: compare the extracted total with its line amounts. A person must inspect the document."}
    return {"output": {"message": {"role": "assistant", "content": [{"text": json.dumps(value)}]}}, "stopReason": "end_turn",
            "ResponseMetadata": {"RequestId": "authored-bedrock-request"}, "usage": {"inputTokens": 220, "outputTokens": 70}}


class FakeTextract:
    def __init__(self, case="conflict", response=None):
        self.response = response if response is not None else textract_response(case)
        self.calls = []

    def analyze_document(self, **kwargs):
        expected = {"Document": {"S3Object": {"Bucket": CONFIG["bucket"], "Name": pipeline.KEY, "Version": CONFIG["version"]}},
                    "FeatureTypes": ["QUERIES"], "QueriesConfig": {"Queries": pipeline.QUERIES}}
        if kwargs != expected:
            raise AssertionError("Unexpected AnalyzeDocument request or source version.")
        self.calls.append(deepcopy(kwargs))
        return deepcopy(self.response)


class FakeBedrock:
    def __init__(self, case="conflict", response=None, unavailable=False):
        self.response = response if response is not None else bedrock_response(case)
        self.unavailable = unavailable
        self.calls = []

    def converse(self, **kwargs):
        if set(kwargs) != {"modelId", "system", "messages", "inferenceConfig"}:
            raise AssertionError("Unexpected Converse request keys.")
        if kwargs["modelId"] != CONFIG["modelArn"] or kwargs["inferenceConfig"] != {"maxTokens": 240, "temperature": 0}:
            raise AssertionError("Model or output limits changed.")
        if len(kwargs["messages"]) != 1 or kwargs["messages"][0]["role"] != "user" or "tools" in kwargs:
            raise AssertionError("Unbounded conversation/tool request.")
        self.calls.append(deepcopy(kwargs))
        if self.unavailable:
            raise RuntimeError("Authored service failure.")
        return deepcopy(self.response)
