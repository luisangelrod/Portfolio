# Fondeo: connected AWS adapter source

This is the concrete next integration behind the running Fondeo demonstration. It contains actual SDK request construction for **Textract AnalyzeDocument → Bedrock Converse → Python validation**, connected by a generated Standard Step Functions definition and CloudFormation template.

**It has not called AWS.** Local tests inject authored API-shaped responses into the actual adapter functions. The extraction errors, confidence values, model explanations, request IDs and geometry in those fixtures are synthetic, not captured results. The template defaults to disabled AWS calls and removes Textract, Bedrock and S3 permissions while disabled. The running portfolio still uses its Node/SQLite service; this folder is a separate source artifact.

```text
Fixed fictional PDF + server configuration
                 ↓
Explicit demo scope gate
                 ↓
Textract queries: total / first line / second line
                 ↓
Bounded Bedrock explanation with source-block citations
                 ↓                           ↘ unavailable or invalid
Pure Python arithmetic + evidence checks ← validate without a proposal
                 ↓
Needs correction / ready for HUMAN review / denied
```

## Run the local evidence

From this folder, with Python 3.12+ and the standard library:

```sh
python3 build_artifacts.py --check
python3 -m unittest discover -s . -p 'test_*.py' -v
python3 run_local.py --case conflict
python3 run_local.py --case clean
python3 run_local.py --case uncertain
python3 run_local.py --case missing
```

No SDK installation, AWS CLI, credentials, model download, network connection or account is used by these commands. The runner traverses the checked-in ASL and calls `pipeline.invoke` with strict injected clients that assert request shapes. It is not an AWS emulator and does not implement service retries or timing.

The conflicting example reaches `NeedsCorrection`: total $1,800 versus line amounts $900 + $400, despite 97% confidence. A clean example reaches `ReadyForHumanReview`, with `approved: false`. Model outage or malformed output preserves deterministic validation through `ValidateWithoutProposal`. Textract/source failure terminates as `ProcessingFailed` and does not invent document values.

## Files worth reviewing

| File | What it demonstrates |
| --- | --- |
| `pipeline.py` | Real SDK call sites, operator gate, strict adapters, citations, arithmetic and review boundary |
| `fixtures.py` | Clearly authored API-shaped responses and strict local fake clients |
| `test_connected.py` | 27 executed tests, including bad references, tenant denial, stale source version, tampered amounts, model abuse and fallback |
| `state-machine.asl.json` | Generated graph that the local runner actually traverses |
| `template.json` | Generated source-only CloudFormation, exact Lambda version, restricted conditional permissions, no public endpoint |
| `build_artifacts.py` | Reproducible source/template/PDF generation and drift detection |
| `fictitious-invoice-v1.pdf` | Fixed, one-page synthetic source document; not uploaded anywhere |
| `source-manifest.json` | PDF fingerprint and separately authored $1,300 ground truth for a future extraction evaluation |
| `local-conflict-run.json` | Actual local execution of the adapter and ASL wiring using synthetic responses |
| `local-clean-run.json` | Actual local clean-path traversal; still requires human review |
| `validation-status.json` | Commands and source fingerprints for the local validation pass |
| `CONTRACT.md` | Trust, data, lifecycle and deployment boundaries |

The independent manifest value is deliberately **not** fed into the general validator. If OCR gets both the total and the line items wrong in a mutually consistent way, arithmetic passes. A test explicitly demonstrates this limitation. The live acceptance test must compare the real extraction with this separately authored source and visually inspect the cited geometry.

## What a later operator must review

No deployment or invocation command is supplied or executed here. Before activating anything, review the template and a change set in a separately authorized sandbox:

1. Inspect the generated fictional PDF, verify its SHA-256, place only that reviewed document at the fixed S3 key, and select its immutable object version. The source file is not uploaded by this kit.
2. Configure `SourceBucket`, `SourceVersion`, and one regional `ModelArn` that supports Converse with the selected controls. The defaults are obvious placeholders. Inference profiles, arbitrary documents, KMS configuration and other regions/models require their own review. This bounded kit accepts version IDs up to 40 characters and model ARNs up to 110 characters.
3. Validate CloudFormation and ASL with the actual AWS services; verify IAM behavior, runtime SDK/model compatibility, region support, quotas, cost and resource lifecycle. None of those checks has been performed locally.
4. Review changing `EnableAwsCalls` from its default `false`. That change grants metered service capability and publishes a new Lambda version. It does not start an execution, authenticate a person or persist an approval.
5. Capture real Textract block geometry/request IDs and real Bedrock output. Test model/source failures and actual review routing. Keep this new cloud receipt separate from the synthetic local receipts.

## Current proof and remaining work

Locally demonstrated: exact API request construction, bounded response parsing, source reference retention, deterministic integer-cent rules, safe rejection of extra model fields/citations, ASL routing, fallback behavior, immutable-version configuration references, exact generated-source agreement and compileable embedded Python.

Not demonstrated: live OCR accuracy, actual model behavior, regional model availability, AWS IAM enforcement, CloudFormation/ASL service validation, Python 3.13 Lambda runtime, SDK compatibility in that runtime, retry behavior, quotas, live cost, deployment, production authentication, document ownership or persisted human approvals. Fingerprints detect differences; they are not signatures or proof that a response is true.

The existing authored v1 kit in the parent folder is unchanged. Its old receipt describes its own source, not this integration.

## Official API references

- [Textract AnalyzeDocument](https://docs.aws.amazon.com/textract/latest/APIReference/API_AnalyzeDocument.html): synchronous query request and versioned S3 source.
- [Textract Block](https://docs.aws.amazon.com/textract/latest/APIReference/API_Block.html): operation-scoped IDs, query relationships, confidence, page and bounds.
- [Bedrock Converse](https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_Converse.html): message/inference request and response structure.
- [Step Functions Lambda integration](https://docs.aws.amazon.com/step-functions/latest/dg/connect-lambda.html): parsed Payload and version-qualified invocation.
- [Lambda Version](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-lambda-version.html): immutable snapshots and Description replacement behavior.

No Amazon A2I dependency is introduced. Human review remains an application-owned action to integrate and verify later.
