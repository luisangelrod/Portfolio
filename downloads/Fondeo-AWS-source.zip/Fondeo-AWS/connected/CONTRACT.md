# Connected adapter contract

## Authority and identity

Only the operator configuration selects the source bucket, fixed key `fondeo-demo/fictitious-invoice-v1.pdf`, immutable version, and model ARN. The execution envelope accepts only a schema version, request ID, explicit demo identity and fixed document ID. Extra fields cannot override configuration. A cross-demo-tenant request is denied before either service request.

`explicit-demo-identity` remains a supplied demonstration context, not authenticated identity. The template has no public endpoint or starter permission. A future authenticated starter must resolve ownership and create this envelope from a verified principal. Anyone granted direct invocation of the internal functions can still fabricate an input payload; this kit does not claim to authenticate the origin of an OCR response or a saved approval.

## Invocation gate

`ENABLE_AWS_CALLS` defaults to false. The live branch checks it before importing boto3 or constructing clients, so the disabled path does not resolve AWS credentials. Invalid input or denied scope does not make service calls. Tests use dependency injection, require `enabled: false` and `evidenceMode: authored-api-fixtures`, and cannot label injected results as live execution.

CloudFormation also omits S3, Textract and Bedrock policy statements when the operator switch is false. The single internal Lambda has only its own log permissions until explicitly enabled. Once enabled, it can read the exact S3 object version, call AnalyzeDocument (an action with broad resource authorization), and invoke one configured regional foundation model. This source/role design is reviewable, not proof of actual IAM enforcement. No automatic execution or public starter exists.

## Evidence contract

The source is one reviewed, single-page fictional invoice. The adapter sends three fixed queries and consumes only their matching QUERY → ANSWER relationships. Each accepted field retains the query ID, answer block ID, text, integer cents, confidence, page and bounding box. Operation request ID, extraction model version and bounded response fingerprint remain attached. Duplicate, reused, missing-linked, wrong-page and out-of-bounds references are rejected. An unanswered query remains absent and requires review.

Normalization accepts unambiguous dollar amounts with exactly two decimals and bounded integer cents. It never guesses a locale, separator, negative sign or missing decimal. The deterministic validator reparses text, checks stored normalized amounts and references, requires all three fields, compares line-item arithmetic, and applies a stated 80% demonstration threshold. That threshold is not an AWS recommendation.

Arithmetic compares extracted fields. It is not an independent observation of the invoice. The separately authored manifest describes expected test-document truth; it is excluded from validation to avoid an OCR value being certified by a copy of itself. Correct arithmetic and high confidence still end at human review.

## Model boundary

Converse receives the extracted field evidence and a fixed versioned prompt. It gets no credentials, tenant context, source bucket, tool access, arbitrary conversation or external URL. The request caps output at 240 tokens; the response is capped at 16 KiB and its sole text block at 4 KiB. Only a completed `end_turn` response containing one JSON object is accepted.

The proposal may identify a known field, cite up to three known block IDs and explain its reasoning in at most 320 characters. It cannot provide a replacement amount, approval, verified flag, tenant or rule result. Selected fields require their own source citation. Model text remains untrusted prose and must be rendered as text by a future UI. Raw model text, parsed proposal, request ID, configured model ARN and prompt version remain attached to the unchanged evidence. Schema validation proves shape and references, not whether the explanation is correct.

Model service failure, truncation or invalid output goes through `ValidateWithoutProposal`. Arithmetic and review remain available, with `proposalUnavailable: true`. Source extraction failure goes to `ProcessingFailed`, never a synthetic replacement result.

## Workflow and lifecycle

The generated ASL uses Standard Step Functions, JSONPath Parameters, optimized Lambda invocation and `$.Payload`. Each task has a 40-second deadline; the Lambda has a 35-second deadline; SDK connect/read timeouts are 3/25 seconds with no SDK retry; the overall workflow deadline is 180 seconds. One additional retry is allowed for listed Lambda infrastructure errors. Business review outcomes are values, not retry triggers. The local subset runner exercises wiring and catch routes but not timing, AWS errors, IAM or the service runtime.

The workflow role invokes one immutable Lambda version. Its logical ID contains the code/runtime-definition hash. Its replacement-triggering version Description includes all configurable environment values, so changing the enabled switch, source or model also publishes a new version. Parameter limits keep the description within 256 characters. Retained old versions need later operator cleanup. Concurrency is limited to one; logs retain seven days. These limits bound a demonstration and are not a complete billing or abuse-control system.

The PDF is generated deterministically and fingerprinted locally. A later operator must verify the exact S3 version matches those bytes; the runtime does not download the object separately to rehash it. Standard workflow history contains the synthetic source references, extraction and explanation. Private intake and retention need separate implementation.

No approval persistence, mutation transaction, payment action, deployment hook or autonomous repair is included. `ReadyForHumanReview` always contains `approved: false` and `requiresHumanReview: true`. The local Fondeo service remains the separately tested implementation of revisions and approvals.
