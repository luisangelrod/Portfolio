"""Pure validation boundary for Fondeo. Standard library only; no AWS calls.

context is a DEMO execution input, not authenticated identity. A production
starter must derive it from an authenticated principal and authorize the document.
"""
import hashlib
import json
import math
import re

RULE_VERSION = "invoice-integrity-aws-1"
TOKEN = re.compile(r"^[a-zA-Z0-9_-]{1,100}$")
MAX_CENTS = 100_000_000


class InvalidInput(ValueError):
    pass


def fields(value, names):
    if not isinstance(value, dict) or set(value) != set(names):
        raise InvalidInput("Unexpected or missing fields.")


def token(value):
    if not isinstance(value, str) or not TOKEN.fullmatch(value):
        raise InvalidInput("Identifiers must contain 1–100 letters, numbers, hyphens or underscores.")


def cents(value):
    if type(value) is not int or not 0 <= value <= MAX_CENTS:
        raise InvalidInput("Amounts must be integer cents from zero to 100000000.")


def gate(envelope):
    fields(envelope, ["schemaVersion", "requestId", "context", "document"])
    if envelope["schemaVersion"] != "fondeo-input/1":
        raise InvalidInput("Unsupported input schema.")
    token(envelope["requestId"])
    fields(envelope["context"], ["tenantId", "actorId", "identityMode"])
    fields(envelope["document"], ["id", "tenantId", "fixture"])
    for value in [envelope["context"]["tenantId"], envelope["context"]["actorId"],
                  envelope["document"]["id"], envelope["document"]["tenantId"]]:
        token(value)
    if envelope["context"]["identityMode"] != "explicit-demo-identity":
        raise InvalidInput("This kit supports explicit demo identity only.")
    if envelope["document"]["fixture"] not in ["clean", "conflict", "uncertain", "missing"]:
        raise InvalidInput("Choose a supported authored fixture.")
    if envelope["context"]["tenantId"] != envelope["document"]["tenantId"]:
        return {"status": "denied", "reason": "document-tenant-mismatch", "ruleVersion": RULE_VERSION}
    return {"status": "accepted", "envelope": envelope}


def validate(payload):
    fields(payload, ["schemaVersion", "envelope", "source", "extraction", "provenance"])
    if payload["schemaVersion"] != "fondeo-extraction/1":
        raise InvalidInput("Unsupported extraction schema.")
    gate_result = gate(payload["envelope"])
    if gate_result["status"] != "accepted":
        return gate_result  # Withhold values and references for another tenant.
    source, extracted = payload["source"], payload["extraction"]
    fields(source, ["present", "totalCents", "reference"])
    fields(extracted, ["amountCents", "confidence", "lineItems", "sourceReference"])
    if type(source["present"]) is not bool:
        raise InvalidInput("Source presence must be boolean.")
    if source["present"]:
        cents(source["totalCents"])
    elif source["totalCents"] is not None:
        raise InvalidInput("An absent source must not claim a source total.")
    cents(extracted["amountCents"])
    confidence = extracted["confidence"]
    if type(confidence) not in [int, float] or not math.isfinite(confidence) or not 0 <= confidence <= 100:
        raise InvalidInput("Confidence must be a finite number from 0 to 100.")
    lines = extracted["lineItems"]
    if not isinstance(lines, list) or not 1 <= len(lines) <= 50:
        raise InvalidInput("Provide 1–50 line items.")
    for line in lines:
        fields(line, ["id", "amountCents"])
        token(line["id"])
        cents(line["amountCents"])
    if len({line["id"] for line in lines}) != len(lines):
        raise InvalidInput("Line item identifiers must be unique.")
    document = payload["envelope"]["document"]
    for reference in [source["reference"], extracted["sourceReference"]]:
        fields(reference, ["tenantId", "documentId", "documentVersion", "operationId", "blockId"])
        for value in reference.values():
            token(value)
        if reference["tenantId"] != document["tenantId"] or reference["documentId"] != document["id"]:
            return {"status": "denied", "reason": "source-reference-scope-mismatch", "ruleVersion": RULE_VERSION}
    fields(payload["provenance"], ["adapter", "evidence"])
    if payload["provenance"] != {"adapter": "authored-fixture/1", "evidence": "synthetic-not-recorded"}:
        raise InvalidInput("Only the reviewed fixture adapter contract is enabled.")
    total = sum(line["amountCents"] for line in lines)
    rules = [
        {"id": "source", "pass": source["present"]},
        {"id": "arithmetic", "pass": total == extracted["amountCents"]},
        {"id": "source-total", "pass": source["present"] and source["totalCents"] == extracted["amountCents"]},
        {"id": "confidence", "pass": confidence >= 80},
        {"id": "source-reference", "pass": source["reference"] == extracted["sourceReference"]},
    ]
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    return {
        "status": "ready" if all(rule["pass"] for rule in rules) else "review",
        "ruleVersion": RULE_VERSION, "rules": rules, "requestId": payload["envelope"]["requestId"],
        "tenantId": document["tenantId"], "documentId": document["id"],
        "amountCents": extracted["amountCents"], "lineTotalCents": total,
        "sourceReference": source["reference"], "inputSha256": digest,
        "requiresHumanReview": True, "approved": False, "provenance": payload["provenance"],
    }


def handler(event, _context=None):
    try:
        # Also rejects Python-only nonfinite values before fingerprinting.
        if len(json.dumps(event, allow_nan=False).encode()) > 32_768:
            raise InvalidInput("Input exceeds the 32 KiB review limit.")
        fields(event, ["operation", "payload"])
        if event["operation"] == "gate":
            return gate(event["payload"])
        if event["operation"] == "validate":
            return validate(event["payload"])
        raise InvalidInput("Unsupported operation.")
    except (InvalidInput, ValueError, TypeError) as error:
        return {"status": "invalid", "reason": str(error), "ruleVersion": RULE_VERSION}
