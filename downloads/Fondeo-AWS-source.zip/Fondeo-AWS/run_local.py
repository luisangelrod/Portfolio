"""Run THIS ASL file's Task/Choice/Succeed/Fail subset locally; not an AWS emulator."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import extraction_adapter
import validator

ROOT = Path(__file__).resolve().parent


def select(value, expression):
    if expression == "$":
        return value
    if not expression.startswith("$."):
        raise ValueError("Unsupported local JSONPath.")
    for key in expression[2:].split("."):
        value = value[key]
    return value


def parameters(definition, value):
    result = {}
    for key, item in definition.items():
        if key.endswith(".$"):
            result[key[:-2]] = select(value, item)
        else:
            result[key] = parameters(item, value) if isinstance(item, dict) else item
    return result


def run(envelope, functions=None):
    definition = json.loads((ROOT / "state-machine.asl.json").read_text())
    functions = functions or {"${ValidatorArn}": validator.handler, "${ExtractorArn}": extraction_adapter.handler}
    name, value, visited = definition["StartAt"], deepcopy(envelope), []
    for _ in range(30):
        state = definition["States"][name]
        visited.append(name)
        if state["Type"] == "Task":
            try:
                args = parameters(state["Parameters"], value)
                result = {"Payload": functions[args["FunctionName"]](args["Payload"], None)}
                value = select(result, state["OutputPath"])
                name = state["Next"]
            except Exception:
                # Tests exercise catch routing. Service retries/timeouts are not simulated.
                name = state["Catch"][0]["Next"]
        elif state["Type"] == "Choice":
            name = state["Default"]
            for choice in state["Choices"]:
                if select(value, choice["Variable"]) == choice["StringEquals"]:
                    name = choice["Next"]
                    break
        elif state["Type"] in ["Succeed", "Fail"]:
            return {
                "engine": "local-asl-subset-runner/1", "cloudExecution": False,
                "terminal": name, "execution": "succeeded" if state["Type"] == "Succeed" else "failed",
                "visited": visited, "result": value if state["Type"] == "Succeed" else {"error": state["Error"]},
                "limits": "Runs Python and JSONPath wiring only. No IAM, AWS Lambda runtime, retry timing, service quota or deployment verification.",
            }
        else:
            raise ValueError("Unsupported local state type.")
    raise ValueError("Exceeded bounded local state traversal.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "example-input.json")
    parser.add_argument("--fixture", choices=list(extraction_adapter.FIXTURES))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    value = json.loads(args.input.read_text())
    if args.fixture:
        value["document"]["fixture"] = args.fixture
    text = json.dumps(run(value), indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
