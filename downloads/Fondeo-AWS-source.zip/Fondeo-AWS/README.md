# Fondeo: optional AWS extension kit

A concrete interview artifact for a document-processing stack: Python Lambda validation, an explicit extraction adapter, Standard Step Functions routing, and generated CloudFormation. It runs locally with the Python standard library. **No AWS resources were created, no cloud service was invoked, and the portfolio continues to use its local document service.**

```text
Demo envelope → input + scope gate → authored extraction adapter
                                           ↓
                                    deterministic validator
                                           ↓
                         correction / ready for human review / denial
```

The extraction is authored data, not Textract output or a Bedrock response. Demo identity is openly supplied in the execution input; production authentication, storage, approval persistence and cloud integration are outside this kit. [CONTRACT.md](CONTRACT.md) specifies the boundary and adapter path.

## Inspect the sources

| File | Purpose |
|---|---|
| `validator.py` | Strict envelope/tenant/reference checks, integer-cent arithmetic, confidence policy, deterministic receipt |
| `extraction_adapter.py` | Four authored scenarios: clean, conflicting, uncertain, missing source |
| `state-machine.asl.json` | Explicit gate/extract/validate/review branches with bounded task retries and failures |
| `build_template.py` | Generates inline Lambda code and ASL from those exact files; detects stale artifacts |
| `template.json` | Reviewable CloudFormation: two functions, immutable versions, scoped roles, log groups, Standard workflow |
| `test_fondeo.py` | Substantive rule, tenant, provenance, state-path and generated-artifact tests |
| `run_local.py` | Executes the checked-in ASL subset against actual local Python functions; not an AWS emulator |
| `example-input.json` | Explicit synthetic demo identity and invoice input |
| `local-run.json` | Actual local result for the conflicting extraction; `cloudExecution: false` |

## Run locally

From this directory (`portfolio-2026/aws/fondeo`):

```sh
python3 build_template.py --check
python3 -m unittest discover -s . -p 'test_*.py' -v
python3 run_local.py --fixture conflict
python3 run_local.py --fixture clean
python3 run_local.py --fixture uncertain
python3 run_local.py --fixture missing
```

After changing Python, runtime configuration, or ASL, regenerate and verify:

```sh
python3 build_template.py
python3 -m unittest discover -s . -p 'test_*.py' -v
python3 run_local.py --fixture conflict --output local-run.json
```

Do not hand-format or edit generated `template.json`; the exact-source drift check is intentional. No dependency installation, API keys, account, Docker image, or AWS credentials are required for these local commands.

## Current validation

On September 5, 2026, **20 Python tests passed** on Python 3.12.2. They executed the actual validator and adapter, traversed the checked-in state graph, compiled embedded Lambda code, checked immutable function references and scoped permissions, and verified exact template/source agreement. The recorded conflicting-invoice run reached `NeedsCorrection`; 97% extraction confidence did not override incorrect arithmetic or source mismatch.

The generated template is approximately 20 KB and fits the inline CloudFormation template-body size bound checked by the tests. Official AWS resource and Amazon States Language documentation informed its syntax. **AWS CloudFormation service validation, `cfn-lint`, AWS Step Functions validation/execution, Python 3.13 Lambda execution, IAM enforcement, and deployment have not been run.** Neither AWS CLI nor cfn-lint was available in this environment. Local state traversal does not validate retry timing or replace an actual cloud integration check.

## Optional cloud review, only in a separately authorized sandbox

The current deliverable stops at local source. These commands are provided for a later reviewer; none was executed.

First, validate the template using a configured AWS CLI. This contacts AWS but creates no stack:

```sh
aws cloudformation validate-template --template-body file://template.json --region us-east-1
```

If deployment is separately approved, create a **reviewable change set** in a sandbox account. This creates a CloudFormation change-set record and does not execute its resource changes:

```sh
aws cloudformation create-change-set --stack-name fondeo-review --change-set-name initial-review --change-set-type CREATE --template-body file://template.json --capabilities CAPABILITY_IAM --parameters ParameterKey=ResourcePrefix,ParameterValue=fondeo-luis-review --region us-east-1
aws cloudformation describe-change-set --stack-name fondeo-review --change-set-name initial-review --region us-east-1
```

Review resource names, IAM roles, immutable versions, log retention, expected metered Lambda/Step Functions/Logs usage, and the explicit demo identity before executing the change set. This kit provides no automatic deployment or resource-execution command. A real cloud acceptance pass must validate the state definition, execute all four fixtures plus tenant denial and unexpected adapter failure, inspect exact version ARNs in history, and attach that evidence separately. `ReadyForHumanReview` is never an approval.

For interviews, lead with the implemented local Fondeo service and its HTTP isolation/revision tests. Present this kit as the inspectable next integration, with a clear distinction between locally executed evidence and cloud work still to verify.
