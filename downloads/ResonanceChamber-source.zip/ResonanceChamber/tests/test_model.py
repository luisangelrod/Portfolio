import copy
import json
import math
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Content" / "Python"))
from resonance_model import chamber_samples, frequency, load_study, relative_coupling, shape, validate_study


class ResonanceModelTests(unittest.TestCase):
    def setUp(self):
        self.study = load_study(ROOT / "Data" / "study.json")

    def test_published_five_metre_axial_frequencies(self):
        room = {"width": 5, "depth": 4, "height": 3}
        for n in range(1, 6):
            self.assertAlmostEqual(frequency(room, [n, 0, 0]), 34.3 * n)

    def test_browser_export_agrees_with_python(self):
        index = self.study["mode"]["index"]
        self.assertAlmostEqual(frequency(self.study["roomMetres"], index), self.study["mode"]["frequency"], places=10)
        self.assertAlmostEqual(relative_coupling(index, self.study["source"]["normalized"], self.study["listener"]["normalized"]), self.study["relativeModalCoupling"], places=10)

    def test_single_mode_node_is_not_broadband_silence(self):
        point = {"x": 0.5, "y": 0.3, "z": 0.2}
        self.assertAlmostEqual(shape([1, 0, 0], point), 0)
        self.assertAlmostEqual(abs(shape([2, 0, 0], point)), 1)

    def test_samples_stay_inside_physical_room_and_keep_signed_field(self):
        samples = list(chamber_samples(self.study))
        self.assertEqual(len(samples), 432)
        room = self.study["roomMetres"]
        for sample in samples:
            self.assertTrue(all(0 <= p <= room[axis] for p, axis in zip(sample["metres"], ("width", "depth", "height"))))
            self.assertTrue(math.isfinite(sample["normalizedPressure"]))
            self.assertLessEqual(abs(sample["normalizedPressure"]), 1)
        self.assertTrue(any(s["normalizedPressure"] > 0 for s in samples))
        self.assertTrue(any(s["normalizedPressure"] < 0 for s in samples))

    def test_invalid_study_is_rejected(self):
        for mutate in (
            lambda s: s.update(schema="unknown"),
            lambda s: s["roomMetres"].update(width=-1),
            lambda s: s["source"]["normalized"].update(x=float("nan")),
            lambda s: s["mode"].update(index=[0, 0, 0]),
            lambda s: s.update(soundSpeedMetresPerSecond=300),
        ):
            invalid = copy.deepcopy(self.study)
            mutate(invalid)
            with self.assertRaises(ValueError):
                validate_study(invalid)


if __name__ == "__main__":
    unittest.main()
