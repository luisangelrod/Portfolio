# Resonance Chamber — Unreal source companion

**Status: source only. Unreal Engine is not available in the checked standard installation locations. The generator has not run inside Unreal; no `.umap`, native render, compiled build or Pixel Streaming session is claimed.**

The free browser instrument is `/lab/resonance/`. This project carries the same ideal acoustic scenario into an Unreal Editor scene: a cutaway room, signed pressure samples, source/listener markers, and a camera. It uses engine basic shapes and generated unlit materials; no downloaded artwork or paid plugins.

## Contents

- `ResonanceChamber.uproject`: project descriptor, with engine association intentionally unset so an installed compatible UE5 version can be selected.
- `Data/study.json`: browser-format scenario, equations, provenance and scientific limits.
- `Content/Python/resonance_model.py`: validated standard-library model; executable without Unreal.
- `Content/Python/build_chamber.py`: explicit editor scene generator. **Not executed in Unreal.**
- `tests/test_model.py`: scientific fixtures and export/model consistency tests that run without Unreal.

## Use when Unreal is available

1. Open this `.uproject` with your installed UE5 editor. Python Editor Script Plugin and Editor Scripting Utilities are enabled in the descriptor. The API references below were checked against UE5.6; runtime compatibility with a chosen engine still needs testing.
2. Save any open levels. The generator stops if there are dirty map packages or if `/Game/ResonanceGenerated` already exists.
3. Optionally replace `Data/study.json` with a JSON export from the browser instrument. Keep its schema and units unchanged.
4. Use the editor's **Execute Python Script** action to run `Content/Python/build_chamber.py`. There is no automatic startup execution.
5. On success, inspect `/Game/ResonanceGenerated/ResonanceChamber`. Pilot the named camera to inspect framing. Verify mesh/material creation and source/listener positions before making renders or packaging anything.

An error can leave partial generated assets in the new folder. The script never silently overwrites them; inspect/preserve those assets before deciding whether to remove or rename them and rerun.

The scene is an editor study, not a finished native application. Python does not drive runtime gameplay here. Interactive native controls, animation, packaged builds and streaming are future work in Blueprint/C++ with their own verification.

## Scientific model

Rigid rectangular boundaries; `c = 343 m/s`; integer mode indices `(nx,ny,nz)` excluding `(0,0,0)`. Frequency is `c/2 * sqrt((nx/Lx)^2+(ny/Ly)^2+(nz/Lz)^2)`. Pressure shape is the product of cosines on the three normalized coordinates. Source-weighted samples use `phi(source) * phi(point)`.

Unreal positions convert metres to centimetres. Pressure marker diameter encodes normalized magnitude; it is not physical displacement. The horizontal section follows listener height. A single-mode node does not imply silence in a real room. This omits damping, absorption, openings, furnishings, direct sound and real transducer response. No absolute sound level or acoustic-treatment guarantee.

## Local model verification

From this folder, run `python3 -m unittest discover -s tests -v`. This verifies the portable equations and input contract. A passing result does not execute Unreal or validate its renderer/API calls.

## Official API references

- [Editor Python setup and editor-only scope](https://dev.epicgames.com/documentation/en-us/unreal-engine/scripting-the-unreal-editor-using-python)
- [EditorActorSubsystem](https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/EditorActorSubsystem?application_version=5.6)
- [LevelEditorSubsystem](https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/LevelEditorSubsystem?application_version=5.6)
- [MaterialEditingLibrary](https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/MaterialEditingLibrary?application_version=5.6)

Pixel Streaming runs Unreal on a rendering host and delivers media to the browser; it is not static HTML export. No stream is included or configured. See [Epic's overview](https://dev.epicgames.com/documentation/unreal-engine/overview-of-pixel-streaming-in-unreal-engine?lang=en-US) and the [scientific/browser-delivery research](../../research/science-and-unreal.md).
