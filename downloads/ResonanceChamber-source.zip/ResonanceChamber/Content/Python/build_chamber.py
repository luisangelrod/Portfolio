"""Run explicitly in Unreal Editor: Tools > Execute Python Script.

SOURCE ONLY: API references checked; this script has not run inside Unreal.
It creates a new generated folder and refuses existing assets/dirty maps.
"""
import sys
from pathlib import Path

import unreal

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from resonance_model import chamber_samples, frequency, load_study, relative_coupling

PROJECT_DIR = SCRIPT_DIR.parents[1]
STUDY_FILE = PROJECT_DIR / "Data" / "study.json"
OUTPUT = "/Game/ResonanceGenerated"
LEVEL_PATH = OUTPUT + "/ResonanceChamber"


def build_chamber():
    study = load_study(STUDY_FILE)
    if unreal.EditorAssetLibrary.does_directory_exist(OUTPUT):
        raise RuntimeError("/Game/ResonanceGenerated already exists. Preserve or rename it before creating another study; nothing was overwritten.")
    if unreal.EditorLoadingAndSavingUtils.get_dirty_map_packages():
        raise RuntimeError("Save your open levels before running this generator. Nothing was changed.")

    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    cube = unreal.load_asset("/Engine/BasicShapes/Cube.Cube")
    sphere = unreal.load_asset("/Engine/BasicShapes/Sphere.Sphere")
    if not cube or not sphere:
        raise RuntimeError("Engine basic shapes could not be loaded. Nothing was changed.")
    if not levels.new_level(LEVEL_PATH):
        raise RuntimeError("Unreal could not create the new Resonance level.")

    def material(name, rgb):
        result = unreal.AssetToolsHelpers.get_asset_tools().create_asset(name, OUTPUT, unreal.Material, unreal.MaterialFactoryNew())
        if not result:
            raise RuntimeError("Could not create material " + name)
        result.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)
        expression = unreal.MaterialEditingLibrary.create_material_expression(result, unreal.MaterialExpressionConstant3Vector, -250, 0)
        expression.set_editor_property("constant", unreal.LinearColor(*rgb, 1.0))
        unreal.MaterialEditingLibrary.connect_material_property(expression, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)
        unreal.MaterialEditingLibrary.recompile_material(result)
        if not unreal.EditorAssetLibrary.save_loaded_asset(result):
            raise RuntimeError("Could not save material " + name)
        return result

    graphite = material("M_Graphite", (0.006, 0.009, 0.012))
    chalk = material("M_Chalk", (0.87, 0.85, 0.80))
    coral = material("M_PositivePressure", (0.84, 0.22, 0.13))
    blue = material("M_NegativePressure", (0.30, 0.58, 0.74))

    def mesh_actor(label, mesh, position_m, scale_m, surface):
        actor = actors.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(*(coordinate * 100 for coordinate in position_m)))
        if not actor:
            raise RuntimeError("Could not spawn " + label)
        actor.set_actor_label(label)
        actor.static_mesh_component.set_static_mesh(mesh)
        actor.static_mesh_component.set_material(0, surface)
        # Engine basic shapes span 100 cm; one scale unit is one metre here.
        actor.set_actor_scale3d(unreal.Vector(*scale_m))
        return actor

    room = study["roomMetres"]
    width, depth, height = room["width"], room["depth"], room["height"]
    mesh_actor("Room floor", cube, (width / 2, depth / 2, -0.04), (width, depth, 0.08), graphite)
    mesh_actor("Back section wall", cube, (width / 2, -0.04, height / 2), (width, 0.08, height), graphite)
    mesh_actor("Side section wall", cube, (-0.04, depth / 2, height / 2), (0.08, depth, height), graphite)
    for x in (0, width):
        for y in (0, depth):
            mesh_actor("Room corner", cube, (x, y, height / 2), (0.012, 0.012, height), chalk)
    for z in (0, height):
        for y in (0, depth):
            mesh_actor("Width boundary", cube, (width / 2, y, z), (width, 0.012, 0.012), chalk)
        for x in (0, width):
            mesh_actor("Depth boundary", cube, (x, depth / 2, z), (0.012, depth, 0.012), chalk)

    count = 0
    for sample in chamber_samples(study):
        pressure = sample["normalizedPressure"]
        if abs(pressure) < 0.002:
            continue
        diameter = 0.018 + abs(pressure) * 0.13
        mesh_actor("Pressure sample %03d (%+.5f)" % (count, pressure), sphere, sample["metres"], (diameter,) * 3, coral if pressure >= 0 else blue)
        count += 1
    for name, surface in (("source", coral), ("listener", chalk)):
        point = study[name]["normalized"]
        position = (point["x"] * width, point["y"] * depth, point["z"] * height)
        marker = mesh_actor(name.title(), cube if name == "source" else sphere, position, (0.16,) * 3, surface)
        if name == "source":
            marker.set_actor_rotation(unreal.Rotator(0, 45, 45), False)

    camera_position = unreal.Vector(width * 145, depth * 150, height * 160)
    camera = actors.spawn_actor_from_class(unreal.CineCameraActor, camera_position)
    if camera:
        camera.set_actor_label("Resonance section camera")
        target = unreal.Vector(width * 50, depth * 50, height * 40)
        camera.set_actor_rotation(unreal.MathLibrary.find_look_at_rotation(camera_position, target), False)
        camera.get_cine_camera_component().set_editor_property("current_focal_length", 28.0)
    if not levels.save_current_level():
        raise RuntimeError("The chamber exists in the editor but could not be saved. Save the level manually.")
    actors.clear_actor_selection_set()
    index = study["mode"]["index"]
    coupling = relative_coupling(index, study["source"]["normalized"], study["listener"]["normalized"])
    unreal.log("Resonance generated: %s; %.5f Hz; %.3f%% relative modal coupling; %d pressure markers. Ideal model, not measured acoustics." % (LEVEL_PATH, frequency(room, index), coupling * 100, count))


if __name__ == "__main__":
    build_chamber()
