"""Standard-library model shared by the source-only Unreal companion.

This module runs without Unreal. It does not create a map or render a scene.
"""
import json
import math
from pathlib import Path

SOUND_SPEED = 343.0
SCHEMA = "rigid-room-1.0"


def _finite(value, low, high):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and low <= value <= high


def validate_study(study):
    if not isinstance(study, dict) or study.get("schema") != SCHEMA:
        raise ValueError("Expected a Resonance rigid-room-1.0 study export.")
    room = study.get("roomMetres", {})
    if not isinstance(room, dict) or not all(_finite(room.get(axis), 1, 30) for axis in ("width", "depth", "height")):
        raise ValueError("Room dimensions must be finite values from 1 to 30 metres.")
    mode = study.get("mode", {})
    index = mode.get("index") if isinstance(mode, dict) else None
    if not isinstance(index, list) or len(index) != 3 or not any(index) or not all(isinstance(n, int) and not isinstance(n, bool) and 0 <= n <= 24 for n in index):
        raise ValueError("Expected three nonnegative mode indices, not all zero.")
    for name in ("source", "listener"):
        value = study.get(name, {})
        point = value.get("normalized", {}) if isinstance(value, dict) else None
        if not isinstance(point, dict) or not all(_finite(point.get(axis), 0, 1) for axis in ("x", "y", "z")):
            raise ValueError("Source and listener must be normalized points inside the room.")
    if study.get("soundSpeedMetresPerSecond") != SOUND_SPEED:
        raise ValueError("This model uses a fixed 343 m/s sound speed.")
    return study


def load_study(path):
    path = Path(path)
    if path.stat().st_size > 65536:
        raise ValueError("Study file exceeds 64 KiB.")
    return validate_study(json.loads(path.read_text(encoding="utf-8")))


def frequency(room, index):
    return SOUND_SPEED / 2 * math.sqrt(sum((n / room[axis]) ** 2 for n, axis in zip(index, ("width", "depth", "height"))))


def shape(index, point):
    return math.prod(math.cos(math.pi * n * point[axis]) for n, axis in zip(index, ("x", "y", "z")))


def relative_coupling(index, source, listener):
    return abs(shape(index, source) * shape(index, listener))


def chamber_samples(study, columns=24, rows=18):
    validate_study(study)
    if not isinstance(columns, int) or not isinstance(rows, int) or not 2 <= columns <= 64 or not 2 <= rows <= 64:
        raise ValueError("Sampling dimensions must be integers from 2 to 64.")
    room, index = study["roomMetres"], study["mode"]["index"]
    source = study["source"]["normalized"]
    z = study["listener"]["normalized"]["z"]
    weight = shape(index, source)
    for row in range(rows):
        for column in range(columns):
            point = {"x": (column + 0.5) / columns, "y": (row + 0.5) / rows, "z": z}
            yield {
                "metres": (point["x"] * room["width"], point["y"] * room["depth"], point["z"] * room["height"]),
                "normalizedPressure": weight * shape(index, point),
            }
